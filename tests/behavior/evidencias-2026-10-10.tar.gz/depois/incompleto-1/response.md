Vamos começar pelo **contexto e pelo objetivo da avaliação**. Na referência MEDS local, essas informações orientam o rigor necessário e as escolhas de avaliação.

Já temos: organizador de documentos para estudantes, protótipo disponível, prazo de duas semanas, acesso a usuários ainda não confirmado e interesse em avaliar utilidade. O planejamento ficará somente no chat.

Para esta etapa, preciso entender:

1. **Qual problema o organizador resolve e para quais estudantes?** Descreva uma tarefa concreta, como encontrar um material de disciplina, e como eles a realizam hoje. Isso ajuda a definir o que seria uma melhoria útil.

2. **O que já funciona no protótipo?** Quais tarefas podem ser realizadas do início ao fim e quais funcionalidades ainda são simuladas? Isso delimita o que podemos avaliar.

3. **Que decisão você quer tomar com a avaliação, e quem precisa da evidência?** Por exemplo: decidir o que melhorar, se vale continuar o desenvolvimento ou sustentar uma conclusão em um trabalho acadêmico. Isso orienta a finalidade e o rigor da avaliação.

4. **Quanto das duas semanas pode ser dedicado à avaliação?** Informe quem ajudaria, os recursos disponíveis e se existe algum caminho possível para conseguir estudantes, mesmo sem confirmação. Isso define a viabilidade do planejamento.

5. **O protótipo usaria documentos reais?** Há dados pessoais, arquivos sensíveis ou possibilidade de perder ou modificar documentos? Isso esclarece os riscos que precisam entrar no plano.

Pode responder pelos números; o que ainda não souber ficará como pendência.
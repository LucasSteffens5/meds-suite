Li `skill/SKILL.md`, o fluxo Revisar e a referência MEDS, somente nesta pasta.

Para revisar a coerência, preciso do plano: cole seu conteúdo no chat ou informe o caminho do arquivo nesta pasta. Sem esse material, ainda não é possível avaliar objetivos, estratégia, propriedades e episódios.

A revisão será somente no chat, sem criar ou alterar arquivos.
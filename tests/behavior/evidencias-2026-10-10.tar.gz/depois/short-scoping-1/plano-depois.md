# Plano MEDS — Organizador de documentos (caso fictício)

## Contexto

- Identificador: organizador-documentos.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos: duas semanas, computador próprio, sem orçamento adicional.
- Acesso: cinco estudantes e sala da universidade confirmados para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: detalhamento de E1.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.

## 2. Estratégia e trajetória

- Human Risk & Effectiveness: aceita em função dos riscos de uso e do acesso informado.
- E1 formativo naturalístico; episódios posteriores ainda não definidos.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.

## 4. Episódios

### E1 — Uso acompanhado

- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.

#### Proposta de short-scoping de E1 — não aceita

Short-scoping é a redução do escopo de um método para ajustar o esforço ao rigor
necessário à decisão. Esta proposta afeta E1 e a evidência para O1/P1.

- **Escopo original informado neste pedido:** cinco estudantes e três tarefas reais.
  **Corte proposto:** dois estudantes e uma tarefa real no mesmo E1 com Think Aloud.
- **Situação:** somente proposta, sem adoção. Registro da escolha do pesquisador
  neste pedido: "Não aceitei o corte." O escopo original permanece vigente; a
  proposta não altera o acesso confirmado nem as escolhas aceitas de O1, P1 e E1.
- **Justificativa proposta:** reduzir o esforço de uma avaliação formativa diante
  das duas semanas disponíveis, concentrando a observação em uma tarefa relevante
  para decidir melhorias. A tarefa a selecionar e a suficiência dessa evidência
  para a próxima decisão ainda precisam de justificativa; não se presume que o
  escopo original seja inviável.
- **Economia esperada, qualitativa:** menor esforço de coordenação e acompanhamento
  de participantes, preparação de tarefas, registro e análise das observações.
  Não há estimativa de horas, custos ou economia efetivamente obtida.
- **Possíveis efeitos sobre rigor e cobertura:** menos estudantes limitariam a
  diversidade de experiências e a comparação de dificuldades entre usuários;
  uma tarefa cobriria menos situações de busca. A escolha da tarefa ganharia maior
  influência sobre os achados, com risco de não detectar dificuldades presentes
  nas outras duas tarefas ou em outros perfis. A redução, por si só, não garante
  evidência suficiente para O1/P1 nem a mesma força do desenho original.
- **Possíveis efeitos sobre conclusões e riscos residuais:** os achados poderiam
  orientar melhorias relativas aos dois estudantes e à tarefa observada, mas
  sustentariam menos confiança na abrangência dos problemas identificados. A
  ausência de dificuldades não demonstraria usabilidade geral ou cobertura
  suficiente; problemas não observados poderiam persistir. Continuam os limites
  de E1 quanto a causalidade e benefício de longo prazo e a restrição de não medir
  notas nem coletar documentos pessoais. O uso de usuários, sistema e tarefa reais
  preservaria o caráter naturalístico, sem assegurar rigor equivalente.
- **Fundamento e pendências:** *MEDS: Methodology for Evaluation in Design Science*,
  DOI [10.1080/0960085X.2026.2627280](https://doi.org/10.1080/0960085X.2026.2627280),
  tópico "Short-scoping e sinergias", admite reduzir participantes e tarefas desde
  que a evidência continue suficiente. Os efeitos acima são julgamento contextual,
  não resultados de execução. Caso a proposta seja retomada, justificar a seleção
  da tarefa e a suficiência para decidir melhorias, com literatura própria do
  método e aceitação correspondente, antes de alterar o escopo vigente.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

## Pendências

- Detalhar observação de P1 em E1 e buscar literatura própria do método.
- Episódios posteriores não precisam de protocolo agora.

Atualizei somente [plano-meds.md](/private/tmp/meds-v011-o77i0s6a/after-full/short-scoping-1/plano-meds.md), usando a skill local.

A redução para dois estudantes e uma tarefa real está registrada como **proposta não aceita**, com economia esperada qualitativa e possíveis efeitos sobre rigor, cobertura e conclusões. O escopo vigente permanece cinco estudantes e três tarefas reais.

A etapa continua sendo o detalhamento de E1; critérios de observação e protocolo seguem pendentes.
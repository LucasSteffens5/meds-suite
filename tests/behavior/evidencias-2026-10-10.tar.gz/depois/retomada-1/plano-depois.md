# Plano MEDS — Organizador de documentos (caso fictício)

## Contexto

- Identificador: organizador-documentos.
- Última atualização: 2026-10-10.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos: duas semanas, computador próprio, sem orçamento adicional.
- Disponibilidade adicional informada nesta retomada: três sessões de 40 minutos,
  total de 120 minutos. Pendente esclarecer se esse tempo inclui preparação e
  análise ou somente encontros com estudantes; não equivale a tempo individual
  confirmado para cada participante.
- Acesso: cinco estudantes e sala da universidade confirmados para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: detalhamento de E1.
- Próximo passo: delimitar a tarefa real e as dificuldades que precisam ser
  compreendidas para orientar melhorias, e compatibilizar E1 com as janelas de tempo.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.

## 2. Estratégia e trajetória

- Human Risk & Effectiveness: aceita em função dos riscos de uso e do acesso informado.
- E1 formativo naturalístico; episódios posteriores ainda não definidos.
- A estratégia FEDS (quadro para orientar a avaliação em Design Science Research)
  permanece aceita. O novo orçamento de tempo exige verificar a viabilidade de
  E1, sem substituir a estratégia nem alterar o acesso já informado.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.

## 4. Episódios

### E1 — Uso acompanhado

- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.
- Think Aloud significa verbalizar o pensamento durante a tarefa. Sua adequação
  a P1 é apoiada pela síntese MEDS, no tópico DSREMSF (quadro de métodos candidatos
  por finalidade e ambiente): protótipo utilizável e retorno detalhado sobre
  usabilidade. A condição de utilizabilidade precisa ser verificada na preparação.
- Decisão apoiada: escolher melhorias a partir das dificuldades observadas na
  busca, conforme O1. Não há critério de aprovação global da usabilidade definido.
- O limiar de P1 continua pendente; não foi criado valor, escala ou regra de
  sucesso. A ausência de limiar não impede delimitar a observação formativa, mas
  não permite afirmar que a usabilidade atingiu um patamar aceitável.
- A classificação naturalística continua aceita pelas condições reais previstas
  no plano. Ao especificar a tarefa e os materiais, preservar essas condições e
  a restrição de não coletar documentos pessoais. Uma tarefa fictícia exigiria
  reexaminar a classificação de E1, sem atribuir aceitação a essa mudança.
- Responsável pela condução e análise: ainda não informado. Ana permanece
  destinatária da evidência, sem presumir que será a executora.

#### Organização do tempo — proposta, não aceita

Se os 120 minutos forem o recurso total para E1, a distribuição inicial proposta é:

| Sessão | Tempo | Uso proposto |
|---|---|---|
| 1 | 40 min | Delimitar a tarefa real e o foco de observação; consultar literatura específica do método e preparar o protocolo, verificando a utilizabilidade do protótipo. |
| 2 | 40 min | Uso acompanhado, condicionado ao protocolo preparado e à disponibilidade dos estudantes; quantidade de participantes e duração das tarefas ainda pendentes. |
| 3 | 40 min | Analisar os registros das dificuldades e relacioná-los às melhorias que Ana precisa decidir, explicitando os limites da evidência. |

Essa distribuição é um julgamento contextual para organizar o recurso informado,
não uma duração prescrita por MEDS nem garantia de conclusão. A fundamentação está
na síntese MEDS, tópicos Objetivos e propriedades e Short-scoping e sinergias:
equilibrar recursos e rigor suficiente para a próxima decisão formativa.

Os cinco estudantes e a sala continuam com acesso confirmado. Não se presume que
todos possam ser acompanhados em 40 minutos; nenhum participante, tarefa ou etapa
do método foi excluído. Se houver necessidade de reduzir o escopo, registrar o
corte concreto, economia esperada, perda de cobertura, riscos e escolha de Ana
antes de tratá-lo como aceito. Caso o tempo não comporte o desenho, o cronograma
permanece pendente; não comprimir o método silenciosamente.

O protocolo ainda exige literatura própria de Think Aloud; MEDS e FEDS não
fornecem suas instruções de coleta e análise. Nenhuma sessão foi executada.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

Na retomada de 2026-10-10, a pessoa solicitante informou: "Posso dedicar três
sessões de 40 minutos" e "As escolhas aceitas continuam; ainda não tenho limiar
de usabilidade". O1, P1 como Must (avaliação necessária), Human Risk & Effectiveness
e E1 com Think Aloud permanecem aceitos com base na rodada fictícia 1 e nessa
reafirmação. P2 continua proposta.

A disponibilidade agora especificada complementa o contexto anterior de duas
semanas, computador próprio e ausência de orçamento adicional. E1 precisa ter
sua viabilidade temporal examinada; O1 e P1 conservam seu sentido e prioridade.
A divisão das sessões acima é uma nova proposta, sem aceitação documentada.

## Pendências

- Detalhar observação de P1 em E1 e buscar literatura própria do método.
- Informar a tarefa real de busca e as dificuldades que precisam ser compreendidas
  para orientar a próxima melhoria; isso permitirá delimitar a observação de P1
  sem inventar critérios.
- Esclarecer o alcance das três sessões e a disponibilidade dos cinco estudantes
  nessas janelas; isso permitirá verificar a viabilidade do cronograma de E1.
- Manter o limiar de usabilidade pendente, sem solicitar um valor arbitrário nesta
  retomada. Não há base para um julgamento de aprovação de P1.
- Episódios posteriores não precisam de protocolo agora.

## Fontes e materiais do caso

- Plano anterior e informações da retomada: contexto, decisões aceitas e recursos
  do exercício fictício. Não constituem evidência de execução.
- Baskerville, Pries-Heje e Venable (2026), *MEDS: Methodology for Evaluation in
  Design Science*. DOI: 10.1080/0960085X.2026.2627280. Síntese fornecida com a
  skill: Objetivos e propriedades; DSREMSF; Short-scoping e sinergias.
- Venable, Pries-Heje e Baskerville (2016), *FEDS: a Framework for Evaluation in
  Design Science Research*. DOI: 10.1057/ejis.2014.36. Síntese fornecida com a
  skill: Finalidade, ambiente e momento; Estratégias arquetípicas.
- Literatura específica de Think Aloud: pendente. Foram consultadas somente as
  sínteses locais da skill, sem verificação externa dos artigos.

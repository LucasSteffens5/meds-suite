Atualizei [plano-meds.md](/private/tmp/meds-v011-o77i0s6a/after-full/antigo-exportado-1/plano-meds.md) no mesmo caminho, usando somente o material desta pasta.

Preservei as escolhas aceitas, incorporei o registro antigo e documentei aplicabilidade e lacunas. O arquivo pode ser movido sozinho, sem depender do plugin.

A etapa atual é detalhar E1, começando pela versão do algoritmo e pelos critérios de correção. Nenhuma avaliação foi executada.
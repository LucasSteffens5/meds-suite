# Plano MEDS — Avaliação do indexador

Caso fictício isolado. Este documento descreve avaliações futuras: não há
resultados nem validação científica. A atualização organiza as informações
existentes no modelo atual, preservando as escolhas aceitas. Campos sem informação
permanecem pendentes. Justificativas acrescentadas são interpretações de
planejamento, sem atribuir novas decisões a Ana.

O plano contém o registro anterior, as aceitações, as justificativas pertinentes
e as referências por título e DOI. Pode ser movido sozinho para outra pasta sem
depender da instalação da suíte. Os DOI identificam fontes bibliográficas; não
são arquivos locais necessários para abrir ou retomar o plano.

## Contexto

- **Identificador do caso:** `avaliacao-indexador`, atribuído nesta atualização
  apenas para organização; nome preservado: Avaliação do indexador.
- **Última atualização:** 2026-10-10. Data das decisões antigas não informada.
- **Etapa atual e próximo passo:** passo 4 de MEDS, detalhamento de E1. Objetivo,
  estratégia, propriedade e episódio com método já aceitos. Identificar a versão
  do algoritmo e detalhar critérios verificáveis de correção; avaliação futura.
- **Problema da pesquisa e finalidade da solução:** o algoritmo realiza
  indexação; problema de pesquisa, contexto de aplicação e finalidade mais ampla
  não informados. Examinar correção de saídas é a finalidade da avaliação, não
  uma descrição completa da finalidade da solução.
- **Artefato a avaliar:** algoritmo puramente técnico de indexação, já
  implementado, conforme o registro antigo. Classificação produto/processo e
  criticidade para segurança não informadas. Versão pendente.
- **Questão de pesquisa:** não informada.
- **Estágio do projeto de Design Science Research (DSR, pesquisa em ciência do
  design):** não informado; sabe-se apenas que o algoritmo está implementado e a
  avaliação é futura.
- **Destinatária da evidência e necessidade conhecida:** pesquisadora Ana;
  julgar correção de saídas em casos sintéticos. Exigências adicionais de rigor
  ou apresentação da evidência não informadas.
- **Recursos, acesso, riscos e restrições:** uma semana e computador próprio;
  sem participantes. Datas, disponibilidade efetiva, características do computador,
  ambiente de execução, orçamento e recursos das demais atividades DSR não
  informados. Riscos técnicos e de uso futuro não descritos; ausência de
  participantes não comprova ausência desses riscos.
- **Restrições na formulação do pesquisador:** “Quero examinar correção de saídas
  em casos sintéticos. Não há participantes.”; “Tenho uma semana e computador
  próprio.”

## 1. Objetivos da avaliação

| ID | Objetivo do programa | Relação com a finalidade do artefato | Necessidade de rigor/riscos/recursos | Situação da escolha |
|---|---|---|---|---|
| O1 | Julgar correção das saídas em casos sintéticos. | Examina a correção do algoritmo de indexação; relação com o problema de pesquisa e finalidade mais ampla ainda não documentada. | Critérios verificáveis e saídas esperadas precisam ser definidos; rigor e cobertura a detalhar considerando uma semana, computador próprio e riscos não informados. | Aceita por Ana no registro antigo, preservado em “Fontes e materiais do caso”. |

O1 é o objetivo do programa; P1 é a propriedade do artefato. IDs estáveis são uma
convenção da suíte para relacionar itens. Não há outros objetivos documentados.

## 2. Estratégia e trajetória

- **Estratégia FEDS aceita:** Purely Technical Artefact. FEDS é o quadro de
  avaliação em DSR de Venable, Pries-Heje e Baskerville (2016).
- **Componentes abrangidos:** algoritmo de indexação informado; decomposição em
  componentes não documentada.
- **Orientação da fonte:** *FEDS: a Framework for Evaluation in Design Science
  Research*, tópico “Estratégias arquetípicas” da síntese consultada, favorece
  avaliações artificiais nessa estratégia para artefatos puramente técnicos sem
  aspectos sociais relevantes, ou cuja aplicação humana seja tão distante que a
  avaliação naturalística seja irrelevante ou inviável no projeto. Ser software,
  isoladamente, não basta para essa escolha.
- **Julgamento contextual nesta atualização:** preserva-se a estratégia aceita
  diante da caracterização fornecida de algoritmo puramente técnico e do escopo
  de correção em casos sintéticos. Prazo e computador condicionam o detalhamento,
  sem demonstrar suficiência de recursos. “Não há participantes” não permite
  inferir ausência de efeitos humanos no uso futuro.
- **Trajetória documentada:** um episódio E1 somativo artificial, futuro, sobre
  o algoritmo já implementado. Não há outros episódios informados; não se presume
  avaliação anterior nem se acrescenta sequência obrigatória.
- **Informações para refinar a estratégia:** finalidade mais ampla, contexto de
  uso e riscos, incluindo criticidade para segurança. A migração não mudou o
  contexto informado. Se novos dados trouxerem mudança material, reexaminar
  estratégia e O1/P1/E1 mantendo o histórico; não há substituição proposta aqui.

## 3. Propriedades a avaliar

MuSCoW é a priorização de propriedades em MEDS: Must = precisa ser avaliada;
Should = deveria; Could = poderia; Would = seria desejável incluir também.

| ID | Propriedade e relação com a finalidade do artefato | Objetivos relacionados | MuSCoW: Must/Should/Could/Would | Justificativa | Como observar; critérios conhecidos ou pendentes | Situação da escolha |
|---|---|---|---|---|---|---|
| P1 | Correção das saídas do algoritmo de indexação; finalidade mais ampla pendente. | O1 | Must | Corresponde diretamente ao julgamento solicitado; prioridade Must aceita no plano antigo. | Examinar saídas em casos sintéticos. Comparação com saídas esperadas é orientação de detalhamento, ainda sem protocolo aceito. Casos, saídas esperadas, métricas, limiares e critérios detalhados pendentes. | P1 e prioridade Must aceitas; ver descrição de P1 e fala de Ana no registro antigo preservado. |

Não há outras propriedades documentadas. Must não é limiar numérico nem implica
uma regra de acerto total, pois nenhum limiar foi informado.

## 4. Episódios planejados

Avaliação **somativa** julga atendimento a expectativas, requisitos ou padrões;
**formativa** informa aperfeiçoamentos e como prosseguir. Ambiente **artificial**
abstrai uma ou mais condições reais de usuários, sistema ou tarefa;
**naturalístico** examina uso no contexto real. São eixos contínuos e independentes
em FEDS. Registrar uma classificação principal para consultar DSREMSF (quadro de
seleção de métodos de avaliação em DSR apresentado em MEDS) é convenção operacional
da suíte, sem tornar esses eixos categorias exclusivas.

### E1 — Julgamento da correção em casos sintéticos

- **Finalidade principal, uso da evidência e objetivos:** somativa, aceita;
  julgar correção das saídas, conforme O1. A justificativa decorre desse uso
  pretendido, não do estágio implementado ou do nome Testing. Expectativas e
  critérios detalhados permanecem pendentes.
- **Usos complementares:** não informados; nenhuma finalidade formativa
  complementar documentada como aceita.
- **Propriedades abrangidas:** P1 — correção, prioridade Must aceita.
- **Artefato/versão ou estágio:** algoritmo de indexação implementado;
  versão/identificador do código pendente.
- **Ambiente principal e condições:** artificial, aceito. Sem participantes,
  casos/tarefas sintéticos e algoritmo implementado com versão e ambiente de
  execução pendentes. Casos sintéticos justificam o afastamento da tarefa real.
  Condições parcialmente reais de uso não informadas; código implementado não
  torna, por si, o episódio naturalístico.
- **Métodos candidatos e condições do DSREMSF:** para somativa artificial,
  a síntese de MEDS lista Lab Experiment, Optimisation Analysis, Testing,
  Role Playing Simulation e Computer Simulation. A condição pertinente de
  Testing é software predominante quando funcionamento e saídas corretas são
  essenciais, com testes funcionais/caixa-preta ou estruturais/caixa-branca.
  O registro não selecionou uma dessas modalidades nem documentou necessidade
  de otimização, interação entre papéis ou simulação de uso real.
- **Método aceito e justificativa:** Testing (testes de software), aceito com E1.
  Algoritmo implementado e O1/P1 tornam pertinente a condição descrita acima.
  Essa justificativa contextual não fornece um protocolo de execução; modalidade,
  seleção dos casos e procedimentos ainda pendentes.
- **Momento e escopo:** avaliação futura, ex post em relação à implementação
  informada — classificação temporal acrescentada como interpretação, sem nova
  aceitação atribuída. Escopo preservado: correção das saídas em casos sintéticos,
  sem participantes. Quantidade/cobertura dos casos e calendário na semana
  disponível não informados.
- **Responsáveis previstos:** não informados. Ana é destinatária e autora da
  aceitação registrada; isso não a identifica automaticamente como executora.
- **Recursos e acesso:** uma semana e computador próprio conhecidos. Acesso ao
  código executável, dependências, ferramentas, ambiente e capacidade necessária
  ainda precisam ser documentados; implementação não confirma esses recursos.
- **Evidência esperada:** observações das saídas nos casos sintéticos,
  confrontáveis com critérios definidos. Orientação para detalhamento: registrar
  entradas, saídas esperadas/observadas, versão e condições de execução; formato
  e procedimento ainda não aceitos. Nenhuma evidência produzida nesta atualização.
- **Limitações das conclusões:** julgamento restrito à versão, aos casos e aos
  critérios efetivamente examinados. Não demonstrará automaticamente correção
  universal, efetividade em uso real, segurança ou desempenho. Não há resultados
  ou validação científica do artefato ou da suíte.
- **Decisão apoiada:** julgamento de correção correspondente a O1. Adoção,
  certificação ou outras consequências não informadas.
- **Sinergias:** E1 relaciona O1 e P1; não há outras propriedades ou episódios
  documentados para reunir.
- **Short-scoping (redução deliberada de escopo do método):** nenhum corte
  proposto ou aceito. Casos sintéticos e uma semana são escopo e restrição
  originais, não evidência de redução de um protocolo anterior.
- **Pendências e literatura do método:** versão, critérios/saídas esperadas,
  casos/cobertura, modalidade e protocolo de Testing, responsável, recursos e
  cronograma. Literatura específica de testes de software não fornecida ou
  selecionada; MEDS/DSREMSF orienta a escolha, sem substituir essa literatura.

## Decisões e mudanças

| Data ou contexto disponível | Item/ID | Escolha | Proposta/aceita | Quem decidiu; trecho breve ou localizador da aceitação | Aplicabilidade atual e impacto nos demais itens |
|---|---|---|---|---|---|
| Registro antigo; data não informada | O1 | Julgar correção das saídas. | Aceita | Ana: “Aceito O1, P1, a estratégia e E1 com Testing.”; descrição de O1 em “Registro antigo preservado”. | Mantida no contexto de casos sintéticos; orienta P1 e E1. Critérios detalhados pendentes. |
| Registro antigo; data não informada | P1 | Correção, prioridade Must. | Aceita | Mesma fala de Ana e descrição “P1: correção, Must, aceita.” em “Registro antigo preservado”. | Mantida; E1 deve examinar P1 para atender O1. Sem novo limiar ou cobertura presumidos. |
| Registro antigo; data não informada | Estratégia | Purely Technical Artefact. | Aceita | Mesma fala de Ana e descrição da estratégia em “Registro antigo preservado”. | Mantida para o algoritmo puramente técnico no escopo informado. Uso e criticidade não detalhados; mudanças materiais exigirão reexaminar estratégia e O1/P1/E1 sem apagar aceitação histórica. |
| Registro antigo; data não informada | E1 | Somativo artificial com Testing, relacionado a O1 e P1. | Aceita | Mesma fala de Ana e descrição de E1 em “Registro antigo preservado”. | Mantida; episódio futuro, parcialmente detalhado. Versão, critérios e protocolo pendentes; execução não inferida. |
| 2026-10-10; atualização solicitada pelo usuário | Plano e registros | Migração para o modelo atual, com localizadores, aplicabilidade e lacunas. | Atualização documental solicitada; não é nova escolha metodológica | Pedido de atualizar com informações existentes, mantendo escolhas aceitas e sem inventar dados. | Contexto anterior preservado; sem mudança de escopo, acesso, prioridade ou critérios conhecidos. Nenhum item substituído. |

Os localizadores apontam para o registro incorporado neste arquivo. Aplicabilidade
refere-se ao contexto informado, sem certificar suficiência do desenho. Datas e
autoria ausentes não foram reconstruídas. Justificativas acrescentadas distinguem
orientação das fontes, convenções da suíte e julgamento contextual, sem novas
escolhas aceitas.

## Pendências e próximo passo

| Pendência | Item afetado | Informação ou decisão necessária |
|---|---|---|
| Versão do algoritmo | E1 | Identificar código/versão que será examinado, delimitando e permitindo rastrear a avaliação futura. |
| Critérios de correção | O1, P1, E1 | Especificação de saídas corretas, saídas esperadas para os casos e regra de julgamento; métricas/limiares, se necessários, sem presumir valores. |
| Casos sintéticos e cobertura | P1, E1 | Entradas, comportamentos relevantes e limites da cobertura pretendida; condicionam rigor e alcance das conclusões. |
| Modalidade e protocolo de Testing | E1 | Literatura específica, modalidades pertinentes e procedimento de observação/registro/análise; aceitação ainda não documentada. |
| Recursos operacionais e cronograma | E1 | Responsável, acesso ao código, dependências, ambiente, ferramentas e distribuição do trabalho na semana disponível; não assumir execução por Ana. |
| Rigor necessário à destinatária | O1, E1 | Evidência/cobertura suficientes para o julgamento pretendido e consequências desse julgamento. |
| Problema, finalidade, uso e riscos | Contexto, estratégia, O1, P1, E1 | Documentar aplicação, classificação produto/processo e criticidade para segurança; verificar se novos dados afetam as escolhas preservadas. |
| Questão/estágio DSR e recursos das demais atividades | Contexto | Registrar quando disponíveis para situar o programa e seu equilíbrio de recursos; não impedem a migração documental. |

- **Próxima ação útil:** detalhar E1 começando pela versão do algoritmo e pela
  especificação das saídas corretas em casos sintéticos; depois definir cobertura
  e protocolo compatíveis com uma semana e computador próprio. Registrar propostas
  e eventuais aceitações, sem reabrir automaticamente O1, P1, estratégia ou E1.
  O plano permanece parcial até resolver as lacunas pertinentes ao episódio.

## Fontes e materiais do caso

### Registro antigo preservado

Transcrição do plano anterior à atualização, como fonte do caso e localizador
das aceitações. Data histórica não informada.

> # Avaliação do indexador (caso fictício anterior ao modelo atual)
>
> O artefato é um algoritmo puramente técnico de indexação, já implementado.
> Quero examinar correção de saídas em casos sintéticos. Não há participantes.
> Tenho uma semana e computador próprio. A destinatária é a pesquisadora Ana.
>
> O1: julgar correção, aceito. P1: correção, Must, aceita.
> Estratégia Purely Technical Artefact, aceita. E1: somativo artificial com Testing,
> aceito, relacionado a O1 e P1. Critérios detalhados e versão do algoritmo pendentes.
>
> Registro antigo: Ana disse "Aceito O1, P1, a estratégia e E1 com Testing."
> Não há campo de aplicabilidade nem coluna de localizador neste formato antigo.
> Estas são avaliações futuras; não há resultados ou validação científica.

### Referências metodológicas e localizadores

As justificativas usam as sínteses Markdown fornecidas com o material local deste
exercício. Não houve consulta externa aos artigos nem se presume leitura humana
das fontes. As orientações pertinentes constam no corpo deste plano para permitir
continuidade sem o plugin; títulos e DOI identificam as referências:

- Baskerville, R., Pries-Heje, J., & Venable, J. R. (2026).
  *MEDS: Methodology for Evaluation in Design Science*. European Journal of
  Information Systems, 35(5), 830–847.
  DOI: [10.1080/0960085X.2026.2627280](https://doi.org/10.1080/0960085X.2026.2627280).
  Tópicos da síntese usados: “Processo e seus quatro passos”; “Objetivos e
  propriedades” (MuSCoW); “DSREMSF: métodos candidatos por quadrante” e “Condições
  para orientar a escolha” (Testing somativo artificial); “Short-scoping e
  sinergias”; “Aplicação e limites”.
- Venable, J., Pries-Heje, J., & Baskerville, R. (2016).
  *FEDS: a Framework for Evaluation in Design Science Research*. European Journal
  of Information Systems, 25(1), 77–89.
  DOI: [10.1057/ejis.2014.36](https://doi.org/10.1057/ejis.2014.36).
  Tópicos da síntese usados: “Finalidade, ambiente e momento”; “Estratégias
  arquetípicas” (Purely Technical Artefact); “Evidência e limites”; “Aplicação na
  suíte” (classificação principal como convenção operacional).

Páginas específicas dos artigos não documentadas nas sínteses consultadas.
Fonte específica de Testing ainda não selecionada. A organização segue o modelo
da MEDS Suite 0.1.1; IDs e campos de continuidade são convenções da suíte, não
prova de validade científica.

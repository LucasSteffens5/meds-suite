# Plano MEDS — Organizador de documentos (caso fictício)

## Contexto

- Identificador: organizador-documentos.
- Última atualização: 2026-10-10, retomada do exercício fictício isolado.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos: duas semanas, computador próprio, sem orçamento adicional. Disponibilidade
  informada nesta retomada: três sessões de 40 minutos, total de 120 minutos.
  Pendente esclarecer se esse tempo inclui preparação e análise ou apenas contato
  com os estudantes; não há distribuição de tempo por atividade aceita.
- Acesso: cinco estudantes e sala da universidade confirmados para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: detalhamento de E1.
- Próximo passo: esclarecer a tarefa real de busca, os documentos sem conteúdo
  pessoal e a possibilidade de realizá-la no protótipo; com o alcance das três
  sessões esclarecido, dimensionar E1 e propor a distribuição do tempo.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.

## 2. Estratégia e trajetória

- Human Risk & Effectiveness: aceita em função dos riscos de uso e do acesso informado.
- E1 formativo naturalístico; episódios posteriores ainda não definidos.
- A disponibilidade de 120 minutos exige verificar a viabilidade do desenho de
  E1. Não altera, por si só, as escolhas aceitas de estratégia e classificação;
  sua execução nesse tempo ainda não está dimensionada.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente, conforme reafirmado nesta retomada. Não foi estabelecido
  critério de aprovação/reprovação nem patamar de usabilidade suficiente.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.

## 4. Episódios

### E1 — Uso acompanhado

- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Decisão apoiada: decidir melhorias do protótipo a partir das dificuldades
  observadas, conforme O1; não declarar aprovação da usabilidade sem critérios.
- Recursos: três sessões de 40 minutos informadas; cinco estudantes e sala da
  universidade continuam com acesso confirmado. Quantidade de estudantes por
  sessão, duração das tarefas e tempo de preparação/análise ainda não definidos.
  O limite de tempo não implica redução aceita de participantes ou de tarefas.
- Critérios detalhados de observação e protocolo do método: pendentes.
- Condições a esclarecer para detalhar E1: tarefa real de busca, documentos sem
  conteúdo pessoal e se o protótipo já permite realizar essa tarefa. A classificação
  naturalística aceita pressupõe preservar usuários, sistema e tarefa reais;
  uma tarefa simulada exigiria reexaminar essa classificação.
- Fundamento: a síntese MEDS, em “Condições para orientar a escolha”, associa
  Think Aloud Protocol Analysis (verbalização do pensamento durante o uso) a
  protótipo utilizável e retorno detalhado sobre usabilidade. Em “Short-scoping e
  sinergias”, orienta informação suficiente para a próxima decisão formativa.
  A síntese FEDS, em “Processo original de quatro passos”, orienta dimensionar
  episódios pelos recursos escassos. Julgamento contextual desta retomada: antes
  de propor qualquer corte, dimensionar tarefa, contato, preparação e análise;
  não há evidência disponível de que tudo caiba em 120 minutos.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

- Retomada de 2026-10-10 — recurso informado pela pessoa solicitante: “Posso
  dedicar três sessões de 40 minutos.” Acrescentado ao contexto anterior de duas
  semanas; afeta o dimensionamento de E1. Não há substituição metodológica proposta
  nem corte de escopo aceito.
- Continuidade reafirmada: “As escolhas aceitas continuam; ainda não tenho limiar
  de usabilidade.” Mantidas O1, P1/Must, Human Risk & Effectiveness e E1/Think Aloud,
  com aceitação localizada na fala de Ana, rodada fictícia 1, acima. P2 permanece
  proposta. Limiar de P1 permanece pendente.

## Pendências

- Detalhar observação de P1 em E1 e buscar literatura própria do método.
- Esclarecer se os 120 minutos incluem preparação e análise ou só contato com
  estudantes, para dimensionar o episódio sem supor tempo adicional.
- Especificar a tarefa real e os documentos sem conteúdo pessoal, e esclarecer
  se o protótipo permite realizá-la, para delimitar a observação de P1 em E1.
- Depois dessas respostas, propor distribuição das três sessões e detalhamento
  da observação apoiado em literatura própria de Think Aloud. Se for necessário
  reduzir escopo, explicitar corte, economia, perda de cobertura e riscos antes
  da escolha da pesquisadora; nenhuma redução está aceita nesta retomada.
- Limiar de usabilidade: pendente; não é exigido agora para dimensionar a busca
  formativa por dificuldades. Critérios de observação também continuam pendentes
  e não devem ser confundidos com um limiar de aprovação.
- Episódios posteriores não precisam de protocolo agora.

## Fontes e materiais do caso

- Plano anterior e declarações desta retomada; exercício fictício, sem execução
  de E1 ou resultados registrados.
- *MEDS: Methodology for Evaluation in Design Science*, Baskerville, Pries-Heje
  e Venable (2026), DOI 10.1080/0960085X.2026.2627280. Síntese disponibilizada na
  skill: “Condições para orientar a escolha” e “Short-scoping e sinergias”.
- *FEDS: a Framework for Evaluation in Design Science Research*, Venable,
  Pries-Heje e Baskerville (2016), DOI 10.1057/ejis.2014.36. Síntese disponibilizada
  na skill: “Finalidade, ambiente e momento” e “Processo original de quatro passos”.
- Essas sínteses fundamentam o planejamento; não fornecem o protocolo específico
  de Think Aloud, cuja literatura permanece pendente.

# Plano MEDS — Organizador de documentos (caso fictício)

Este é um exercício fictício isolado. O documento registra planejamento, não
execução ou resultados. As alternativas desta retomada permanecem propostas;
nenhuma substituição de estratégia, método ou ambiente foi aceita.

## Contexto

- Identificador: organizador-documentos.
- Última atualização: 2026-10-10, retomada após mudança de acesso e prazo.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos atuais: três dias. Computador próprio e ausência de orçamento adicional
  constavam no plano e não foram alterados pela informação desta retomada.
- Acesso atual: perdido o acesso aos estudantes e à sala. Não há novo acesso
  confirmado a usuários, avaliadores externos ou outro ambiente real de uso.
- Contexto anterior: duas semanas; cinco estudantes e sala da universidade
  confirmados para tarefas reais. Esse acesso deixou de estar disponível.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Restrições desta retomada: "perdi acesso aos estudantes e à sala; agora só tenho
  três dias"; "Quero manter o objetivo de melhorar usabilidade"; "ainda não aceitei
  substituir estratégia, método ou ambiente".
- Etapa atual: reexaminar a viabilidade da estratégia e da trajetória antes de
  retomar o detalhamento de E1. Próximo passo: decidir entre as alternativas
  propostas, mantendo explícito o alcance da evidência possível.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito na
  rodada fictícia 1 e mantido nesta retomada. A finalidade da solução continua
  sendo ajudar estudantes a encontrar documentos; a finalidade da avaliação é
  fornecer informação para decidir melhorias desse uso.
- Impacto sobre O1: o objetivo continua pertinente, mas a obtenção de evidência
  direta de dificuldades dos estudantes está impedida pelo acesso perdido.
  Uma inspeção pode levantar problemas potenciais, com cobertura e confiança
  diferentes da observação de uso. Não demonstraria melhora efetiva da usabilidade.

## 2. Estratégia e trajetória

- S1 — Human Risk & Effectiveness (risco humano e efetividade): aceita historicamente
  em função dos riscos de uso e do acesso então informado; **a revisar quanto à
  viabilidade atual**, sem substituição aceita. S1 é um identificador atribuído
  nesta retomada para rastrear a estratégia já registrada.
- Trajetória aceita: E1 formativo naturalístico; episódios posteriores ainda não
  definidos. Formativo significa produzir informação para aperfeiçoar o artefato;
  naturalístico exige usuários, sistema e tarefa reais em contexto real.
- Impacto: E1 não pode ser realizado nas condições aceitas com os recursos atuais.
  O prazo caiu de duas semanas para três dias e o acesso real deixou de existir.
  Nenhum episódio artificial foi incorporado à trajetória como decisão aceita.
- Fundamento: *FEDS: a Framework for Evaluation in Design Science Research*,
  tópicos "Finalidade, ambiente e momento" e "Estratégias arquetípicas", admite
  avaliações formativas artificiais iniciais em Human Risk & Effectiveness.
  Assim, propor um episódio artificial não exige automaticamente trocar S1.
  O custo e o acesso precisam ser reexaminados, assim como a possibilidade futura
  de retorno ao uso real. Essa possibilidade ainda é desconhecida.
- Julgamento contextual: a perda de acesso não torna o artefato puramente técnico
  nem elimina os riscos humanos. Três dias, por si só, não justificam Quick & Simple
  (rápida e simples), que pressupõe baixos riscos e incertezas; também não bastam
  para adotar Technical Risk & Efficacy (risco técnico e eficácia). Não há troca
  de estratégia proposta como necessária nem nova aceitação dessas estratégias.

## 3. Propriedades

- P1: usabilidade, Must (precisa ser avaliada), relacionada a O1; aceita e mantida.
  Observação originalmente prevista: dificuldades na busca por estudantes em
  tarefas reais. Essa observação está impedida nas condições atuais; critérios
  detalhados e limiar continuam pendentes. Nas alternativas artificiais abaixo,
  seriam examinadas dificuldades potenciais, sem equivalência com uso observado.
- P2: confiabilidade, Could (poderia ser avaliada), candidata para episódio futuro;
  permanece proposta. Não foi promovida a prioridade nem incorporada aos três dias.
- MuSCoW é a priorização das propriedades em Must, Should, Could e Would.
  A redução de recursos não altera automaticamente a prioridade aceita de P1.

## 4. Episódios

### E1 — Uso acompanhado

- **Situação atual:** aceito historicamente; inviável nas condições de acesso
  informadas. Seu desenho é preservado para rastreabilidade, sem execução agendada
  e sem substituição aceita.
- O1 e P1; protótipo atual, cuja versão não foi identificada; formativo naturalístico.
- Think Aloud Protocol Analysis (análise do protocolo de pensar em voz alta),
  aceito: observar dificuldades com usuários reais, sistema real e tarefa real,
  sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.
- Dependências perdidas: acesso aos cinco estudantes e à sala para tarefas reais.
  Trocar a sala só resolveria parte do problema; falta também acesso aos estudantes.
  A pesquisadora representar estudantes não preservaria o desenho aceito.
- Uma eventual retomada remota dependeria de acesso real restabelecido e de
  condições comprovadas de usuários, sistema e tarefa; o meio remoto sozinho
  não determina se o ambiente é naturalístico. Não se presume essa viabilidade.

### Alternativas para decisão — todas propostas, não aceitas

| ID | Alternativa e efeito sobre o plano | Evidência possível e decisão apoiada | Dependências e limites |
|---|---|---|---|
| A1 | Preservar S1 e E1; adiar a realização de E1. Usar os três dias para preparar critérios de observação e identificar lacunas do protocolo. | Plano mais preparado para futura coleta; não produz evidência nova de usabilidade nem fundamenta melhorias como resultados de avaliação. | Depende de recuperar acesso posteriormente; data e possibilidade desconhecidas. Se houver exigência de avaliar dentro dos três dias, não a atende. |
| A2 | Preservar S1 como referência histórica em revisão e propor E2, formativo artificial, por Criteria-Based Evaluation (avaliação baseada em critérios). E1 fica adiado; E2 não é troca já aceita do método ou ambiente de E1. | Indícios de problemas potenciais em critérios verificáveis da interface, para priorizar o que revisar no protótipo. | Depende de protótipo inspecionável, critérios fundamentados e responsável disponível. Ana é candidata a responsável, não uma avaliadora externa confirmada. Julgamento próprio pode omitir dificuldades reais e favorecer o próprio desenho. |
| A3 | Preservar S1 em revisão e propor E2, formativo artificial, por Scenarios / Scenario Analysis (análise de cenários), como alternativa a A2. | Possíveis obstáculos em caminhos de busca representados em uma árvore de decisões, para decidir quais fluxos revisar. | Depende de tarefas e ramificações sustentadas pela finalidade ou por materiais existentes. Cenários fictícios e percurso da pesquisadora não constituem observação de estudantes; cobertura depende dos caminhos escolhidos. |

- **Recomendação contextual, ainda proposta:** se for necessário obter indícios
  para orientar melhorias nestes três dias, A2 parece a opção mais viável com o
  computador já registrado e sem usuários confirmados, desde que se consigam
  definir critérios verificáveis e um responsável. A3 é alternativa se o problema
  puder ser representado por cenários fundamentados e uma árvore de decisões.
  Se essas condições não forem atendidas ou se o realismo de E1 for indispensável,
  A1 preserva o desenho e explicita que não haverá avaliação executada nesse prazo.
- Fundamento: *MEDS: Methodology for Evaluation in Design Science*, tópico
  "DSREMSF: métodos candidatos por quadrante", relaciona Criteria-Based Evaluation
  a critérios verificáveis por julgamento ou medida e Scenarios a situações
  previsíveis em árvore de decisão. DSREMSF é o quadro de seleção de métodos de
  avaliação em Design Science Research; indica candidatos, não protocolos prontos.
- Convenção da suíte: E2 tem classificação principal **formativa artificial** nas
  propostas A2/A3. A finalidade é orientar melhorias; o ambiente abstrai usuários
  e tarefas reais, mesmo que examine o protótipo existente no computador real.
  A classificação não decorre apenas do nome do método.
- Não se propõem demonstração para interessados, experimento com participantes
  ou simulação computacional como soluções prontas: interessados/participantes,
  desenho experimental e modelo de simulação não estão disponíveis ou definidos.

### E2 — Ficha preliminar condicional para A2 ou A3

- Situação: episódio candidato; não aceito, não executado. A2 e A3 são alternativas
  entre si, não dois métodos já selecionados para execução conjunta.
- Objetivos/propriedade: O1 e P1; decisão apoiada: quais problemas potenciais ou
  fluxos merecem revisão do protótipo e quais dúvidas devem aguardar estudantes.
- Artefato: protótipo atual; versão e disponibilidade para inspeção pendentes.
- Momento: avaliação do protótipo existente para orientar seu próximo aperfeiçoamento;
  relação precisa com o estágio de desenvolvimento ainda não informada.
- Evidência esperada, se aceito e realizado: registro do critério ou cenário,
  localização no protótipo, fundamento do problema potencial, implicação para busca
  de documentos e recomendação de revisão. Critérios de priorização permanecem
  pendentes; não se inventam métricas, limiares ou dados de participantes.
- Salvaguardas mantidas: não medir notas nem coletar documentos pessoais.
  Qualquer material de demonstração fictício precisará ser explicitamente
  identificado e não poderá ser tratado como tarefa real de estudante.
- Responsável: pendente; possibilidade de Ana realizar a inspeção é proposta.
  Não há especialista externo confirmado, nem competência específica documentada.
- Limites: não observa aprendizagem ou dificuldades efetivas dos estudantes;
  não estabelece causalidade, benefício de longo prazo ou efetividade em uso real;
  não permite afirmar que a usabilidade melhorou. Problemas inferidos precisam ser
  distinguidos de dificuldades observadas em eventual retomada de E1.
- Literatura própria do método escolhido e protocolo: pendentes. As sínteses
  metodológicas lidas fundamentam a escolha de candidatos, não a execução.

#### Redução de escopo e uso dos três dias — proposta condicional

- Escopo original: E1 com cinco estudantes, sistema e tarefas reais, em sala,
  no horizonte de duas semanas; critérios e protocolo ainda não detalhados.
- Corte proposto em A2/A3: examinar apenas fluxos de busca prioritários para O1/P1,
  a selecionar e justificar, usando critérios ou cenários; adiar uso acompanhado
  e outras propriedades. Não há quantidade de fluxos definida nem aceita.
- Justificativa: perda de acesso e prazo de três dias. Economia esperada qualitativa:
  dispensa recrutamento e logística de sala no episódio candidato e reduz os
  caminhos analisados. Não há estimativa de horas ou suficiência comprovada.
- Consequências: menor cobertura, ausência de perspectiva direta dos estudantes
  e perda do realismo de E1; risco de omitir dificuldades e priorizar problemas
  aparentes. Trocar método e ambiente é uma alteração metodológica substantiva,
  não apenas encurtar o Think Aloud nem manter sua força de conclusão.
- Distribuição candidata: dia 1, decidir a alternativa, verificar recursos e
  fundamentar critérios/cenários e escopo; dia 2, realizar o episódio somente se
  aceito e preparado; dia 3, consolidar indícios, limites e prioridades de melhoria.
  Horas disponíveis, viabilidade e tempo para implementar melhorias são desconhecidos;
  não se promete avaliação mais implementação dentro do prazo.
- Escolha do pesquisador: **pendente**. A distribuição não constitui agenda aprovada.

## Decisões e mudanças

| Contexto | Item/ID | Registro e autoria disponíveis | Situação e aplicabilidade atual |
|---|---|---|---|
| Rodada fictícia 1, plano anterior | O1, P1, S1, E1, P2 | Ana: "Aceito O1, P1 como Must, Human Risk & Effectiveness e E1 com Think Aloud em tarefas reais. P2 pode continuar proposta." | Aceitação histórica preservada para O1, P1, S1 e E1; P2 proposta. O1 e prioridade P1 mantidos; viabilidade de S1/trajetória a revisar; E1 inviável no contexto atual. |
| Retomada de 2026-10-10 | Recursos, acesso; O1, P1, S1, E1 | Usuário: "perdi acesso aos estudantes e à sala; agora só tenho três dias" e "Quero manter o objetivo de melhorar usabilidade". | Informação atual fornecida; substitui os recursos/acesso anteriores. Mantém O1/P1; exige reexaminar S1 e E1. Não altera P2. |
| Retomada de 2026-10-10 | S1, E1; alternativas A1–A3/E2 | Usuário: "ainda não aceitei substituir estratégia, método ou ambiente". | Nenhuma substituição aceita. A1–A3, E2, corte de escopo e distribuição dos dias são propostas da IA. |

## Pendências e próximo passo

| Pendência | Item afetado | Informação ou decisão necessária |
|---|---|---|
| Escolher resposta à perda de acesso | S1, E1, A1–A3/E2 | Decidir entre adiar E1, propor avaliação por critérios ou propor análise de cenários; nenhuma opção foi aceita. Confirmar se a necessidade é obter indícios neste prazo ou apenas preparar a avaliação futura. |
| Verificar recursos para a alternativa escolhida | E2, se selecionado | Disponibilidade/versão inspecionável do protótipo, responsável, horas nos três dias e material existente para fundamentar critérios ou cenários. Não presumir novos participantes. |
| Confirmar alcance da trajetória | S1, E1 | Possibilidade futura de recuperar usuários e contexto real, ainda desconhecida. Um episódio artificial não completa evidência de efetividade. |
| Fundamentar e detalhar a observação | P1; E1 ou E2 conforme decisão | Literatura específica do método, critérios, escopo e forma de análise; limiar pendente. O protocolo de E1 continua pendente se ele for retomado. |
| Decidir o corte e seus limites | E2, se selecionado | Aceitação do escopo reduzido e da evidência sobre problemas potenciais; não atribuir força equivalente ao desenho original. |

- Próxima pergunta útil: prefere manter E1 para quando recuperar o acesso (A1),
  ou aceita planejar um episódio formativo artificial nestes três dias por
  critérios (A2) ou por cenários (A3), ciente de que ele produz indícios de
  problemas potenciais e não observação do uso pelos estudantes?
- Até essa decisão, o plano está atualizado e parcial. Não avançar para executar
  um método substituto. Episódios posteriores e P2 não precisam de protocolo agora.

## Fontes e materiais do caso

- Plano anterior e declaração de aceitação da rodada fictícia 1; mensagem desta
  retomada. Não há dados empíricos ou resultados de avaliação fornecidos.
- Baskerville, R., Pries-Heje, J., & Venable, J. R. (2026). *MEDS: Methodology for
  Evaluation in Design Science*. DOI:
  [10.1080/0960085X.2026.2627280](https://doi.org/10.1080/0960085X.2026.2627280).
  Fundamento utilizado: síntese fornecida neste exercício, tópicos "Processo e seus
  quatro passos", "DSREMSF: métodos candidatos por quadrante" e "Short-scoping e
  sinergias". Orienta revisitar escolhas e explicitar efeitos da redução de escopo.
- Venable, J., Pries-Heje, J., & Baskerville, R. (2016). *FEDS: a Framework for
  Evaluation in Design Science Research*. DOI:
  [10.1057/ejis.2014.36](https://doi.org/10.1057/ejis.2014.36).
  Fundamento utilizado: síntese fornecida neste exercício, tópicos "Finalidade,
  ambiente e momento" e "Estratégias arquetípicas". Orienta separar estratégia,
  quadrante e método e justificar ambiente pelas condições reais de uso.
- As justificativas usam somente os materiais locais do exercício; não houve
  consulta externa nem leitura integral dos artigos indicada por este registro.

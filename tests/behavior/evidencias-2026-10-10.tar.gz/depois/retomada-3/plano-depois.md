# Plano MEDS — Organizador de documentos (caso fictício)

Este documento registra avaliações planejadas no exercício fictício isolado;
não registra execução nem resultados.

## Contexto

- Identificador: organizador-documentos.
- Última atualização: 2026-10-10.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos: duas semanas, computador próprio, sem orçamento adicional.
- Disponibilidade acrescentada nesta retomada: três sessões de 40 minutos,
  totalizando 120 minutos de dedicação. A janela de duas semanas permanece
  registrada; falta esclarecer se os 120 minutos abrangem preparação, uso
  acompanhado e análise ou apenas o uso acompanhado.
- Acesso: cinco estudantes e sala da universidade confirmados para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: detalhamento de E1.
- Próximo passo: esclarecer a abrangência do tempo disponível e especificar a
  tarefa real de busca e as dificuldades de uso a registrar em E1; depois,
  dimensionar o episódio com base nessas informações.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.

## 2. Estratégia e trajetória

- Human Risk & Effectiveness: aceita em função dos riscos de uso e do acesso informado.
- E1 formativo naturalístico; episódios posteriores ainda não definidos.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.

## 4. Episódios

### E1 — Uso acompanhado

- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.
- Decisão a apoiar: quais melhorias realizar no protótipo a partir das
  dificuldades observadas na busca, conforme O1.
- Recursos: três sessões de 40 minutos de dedicação informadas nesta retomada;
  distribuição entre preparação, uso acompanhado e análise ainda pendente.
  O acesso confirmado aos cinco estudantes e à sala permanece registrado;
  não se presume que os cinco participarão dentro desse tempo.
- Dimensionamento: a viabilidade de E1 com o novo recurso precisa ser examinada
  após esclarecer a abrangência dos 120 minutos e a tarefa real. Nenhum corte
  de participantes, tarefas ou etapas foi proposto ou aceito nesta retomada.
- Observação de P1: especificar quais dificuldades na tarefa serão registradas,
  sem medir notas nem coletar conteúdo de documentos pessoais. Critérios
  detalhados e limiar de usabilidade continuam pendentes, sem valores presumidos.
  A falta de limiar não impede continuar o planejamento formativo de identificação
  de dificuldades; não há base para emitir um julgamento de aprovação da usabilidade.
- Justificativa preservada: a finalidade é formativa porque a evidência orientará
  melhorias; o ambiente previsto é naturalístico pelas condições aceitas de
  usuários, sistema e tarefa reais. Think Aloud permanece aceito para obter
  retorno detalhado sobre usabilidade. O protocolo exige literatura própria
  do método, ainda pendente; o nome do método não fornece um protocolo.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

Na retomada de 2026-10-10, o usuário informou: "Posso dedicar três sessões de
40 minutos"; "As escolhas aceitas continuam"; "ainda não tenho limiar de
usabilidade". O recurso foi acrescentado ao contexto anterior (duas semanas,
computador próprio, sem orçamento adicional), sem substituir as demais condições.
O1, P1 como Must, Human Risk & Effectiveness e E1 com Think Aloud permanecem
aceitos; P2 permanece proposta. E1 e a operacionalização de P1 precisam de
dimensionamento frente ao tempo disponível, preservando o histórico de aceitação.
Não há nova aceitação de critérios, limiares ou redução de escopo.

## Pendências e próximo passo

- E1: esclarecer se as três sessões incluem preparação e análise ou apenas
  uso acompanhado, para dimensionar o trabalho no tempo informado.
- E1/P1: especificar a tarefa real de busca e quais dificuldades de uso serão
  registradas, para detalhar a observação sem inventar critérios.
- E1: após esses esclarecimentos, dimensionar a participação e a distribuição
  do tempo; se for necessário reduzir o escopo, apresentar o corte, a economia
  esperada, as consequências para cobertura/rigor e os riscos residuais como
  proposta, a ser escolhida pelo pesquisador.
- E1: buscar literatura própria de Think Aloud para orientar o posterior
  protocolo de coleta e análise. Essa literatura não foi consultada nesta retomada.
- P1: limiar de usabilidade continua desconhecido; não solicitar um valor
  arbitrário nem tratar a observação de dificuldades como aprovação da propriedade.
- Episódios posteriores não precisam de protocolo agora.

Próxima pergunta: os 120 minutos abrangem todo o trabalho de E1 ou apenas o uso
acompanhado? Qual tarefa real de busca será acompanhada e quais dificuldades de
uso serão registradas, respeitando a restrição sobre documentos pessoais?

## Fontes e materiais do caso

- Plano anterior e informações do usuário nesta retomada: contexto, restrições,
  aceitação das escolhas e disponibilidade; nenhuma evidência empírica produzida.
- *MEDS: Methodology for Evaluation in Design Science* — DOI
  10.1080/0960085X.2026.2627280; síntese local, tópicos "Objetivos e propriedades",
  "DSREMSF: métodos candidatos por quadrante" e "Short-scoping e sinergias".
  Orientação da fonte: equilibrar recursos e rigor, detalhar cada episódio e
  justificar eventuais cortes; Think Aloud é candidato para retorno de usabilidade.
- *FEDS: a Framework for Evaluation in Design Science Research* — DOI
  10.1057/ejis.2014.36; síntese local, tópicos "Finalidade, ambiente e momento"
  e "Processo original de quatro passos". Orientação da fonte: justificar
  finalidade e ambiente e considerar tempo e acesso no desenho dos episódios.
- Convenção da suíte: distinguir informações, aceitação, propostas e pendências;
  documentar consequências e escolha caso se proponha redução de escopo.
- Julgamento contextual nesta retomada: o recurso informado requer dimensionar
  E1; não autoriza deduzir duração por estudante, reduzir o escopo ou fixar um
  limiar. A informação ausente permanece pendente.

Atualizei [plano-meds.md](/private/tmp/meds-v011-o77i0s6a/after-full/retomada-3/plano-meds.md) com **três sessões de 40 minutos (120 minutos)** e o próximo passo de E1. Preservei as escolhas aceitas; critérios e limiar continuam pendentes.

Para dimensionar E1:

1. Os 120 minutos incluem preparação, uso acompanhado e análise, ou apenas uso acompanhado?
2. Qual tarefa real de busca será observada e quais dificuldades deseja registrar, sem coletar documentos pessoais?
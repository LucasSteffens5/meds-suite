# Plano MEDS — Organizador de documentos (caso fictício)

Plano de avaliações futuras em exercício fictício isolado. Esta atualização
registra mudança de contexto e alternativas; não registra execução, resultados
ou aceitação de substituições metodológicas.

## Contexto

- Identificador: organizador-documentos.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Última atualização: 2026-10-10.
- Recursos atuais: três dias. Computador próprio e ausência de orçamento adicional
  constavam do plano e não foram alterados pela mensagem atual.
- Acesso atual: perdido o acesso aos estudantes e à sala. Não há confirmação de
  outros participantes, avaliadores ou ambientes disponíveis.
- Contexto anterior: duas semanas e acesso confirmado a cinco estudantes e à sala
  da universidade para tarefas reais; essas condições deixaram de valer.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Restrição atual do pesquisador: "Este é um exercício fictício isolado; trabalhe
  somente nesta pasta. Não consulte outras instalações da skill."
- Direção atual: "Quero manter o objetivo de melhorar usabilidade."
- Limite de decisão: "ainda não aceitei substituir estratégia, método ou ambiente."
- Etapa atual: reexaminar estratégia e viabilidade de E1 à luz da mudança;
  detalhamento do episódio depende da decisão sobre as alternativas.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.
  Mantido pela direção atual. A finalidade do artefato continua sendo ajudar
  estudantes a encontrar documentos acadêmicos; O1 é o objetivo da avaliação.
  Identificar problemas pode orientar melhorias, mas não demonstra por si só que
  a usabilidade melhorou.

## 2. Estratégia e trajetória

- S1 — Human Risk & Effectiveness (riscos humanos e efetividade em uso real):
  historicamente aceita em função dos riscos de uso e do acesso informado.
  **A revisar**, pois o acesso que sustentava a trajetória foi perdido. O risco
  de uso permanece e o artefato continua sociotécnico; S1 não foi substituída.
- Trajetória aceita: E1 formativo naturalístico; episódios posteriores ainda não
  definidos. E1 está inviável como desenhado no contexto atual.
- Alternativa de trajetória, **proposta**: manter S1, realizar uma avaliação
  formativa artificial inicial e deixar a avaliação com usuários reais pendente
  da recuperação de acesso. FEDS admite episódios artificiais iniciais nessa
  estratégia. Aceitar S1 anteriormente não implica aceitar essa nova trajetória.
- Alternativa estratégica, **apenas para reexame**: Technical Risk & Efficacy
  (riscos técnicos e atribuição de benefício ao artefato) admite avaliação
  artificial quando o uso real é proibitivamente custoso. A perda de acesso
  justifica compará-la, mas não demonstra predominância de risco técnico nem cria
  um objetivo de causalidade. Não há fundamento suficiente para adotá-la agora.
- Três dias não justificam automaticamente Quick & Simple: não foi estabelecido
  que construção, riscos e incertezas sejam todos pequenos. Software sociotécnico
  tampouco se torna Purely Technical Artefact por perder acesso aos usuários.

Fundamento: FEDS, tópicos “Estratégias arquetípicas” e “Finalidade, ambiente e
momento”; MEDS, tópicos “Objetivos e propriedades” e “Short-scoping e sinergias”.
A recomendação contextual é preservar O1/P1 e comparar uma trajetória artificial
inicial com o adiamento de E1; todas as alterações de trajetória seguem propostas.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente. Must significa que precisa ser avaliada; a prioridade
  permanece. A observação direta das dificuldades dos estudantes está inviável
  sem acesso; inspeção ou cenários produziriam evidência diferente e dependem de
  aceitação. Não converter essa propriedade em funcionamento correto do software.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.
  Could significa que poderia ser avaliada. Permanece candidata, sem ampliação
  do escopo em resposta ao prazo curto.

## 4. Episódios

### E1 — Uso acompanhado

- Situação: aceito historicamente; **inviável como desenhado no contexto atual**.
  Método e ambiente abaixo são o desenho histórico, não uma autorização para
  executar um substituto.
- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.
- Decisão pretendida: quais dificuldades na busca devem orientar mudanças no
  protótipo. Versão específica e responsável pela execução não foram informados.
- Dependências perdidas: estudantes e sala para tarefas reais. Não há base para
  afirmar que E1 pode ser realizado nos três dias nem para manter o rótulo
  naturalístico em uma inspeção individual com tarefas fictícias.

### Alternativas para O1/P1 — nenhuma aceita

São alternativas a E1 ou à sua posição na trajetória; não são novos episódios
aprovados. Formativa significa orientar aperfeiçoamento; artificial significa
abstrair ao menos uma condição real de usuários, sistema ou tarefa. A classificação
principal do episódio é uma convenção da suíte para consultar o DSREMSF
(quadro de métodos candidatos), justificada pelas condições concretas.

| ID | Proposta e condições | Estratégia, método e ambiente | Evidência e limites | Viabilidade em três dias |
|---|---|---|---|---|
| A1 | Inspecionar o fluxo de busca do protótipo com critérios explícitos de usabilidade. Depende de acesso ao protótipo utilizável, critérios fundamentados e pessoa disponível com capacidade de julgá-los; não há avaliador externo confirmado. | Proposta de episódio formativo artificial com Criteria-Based Evaluation (avaliação baseada em critérios), candidato DSREMSF quando os critérios são verificáveis. Pode compor S1 como episódio inicial, com revisão da trajetória. Substitui método e ambiente de E1 se escolhida para o prazo atual. | Lista rastreável de problemas potenciais e decisões de melhoria. Sem estudantes, não observa sua experiência; julgamento da própria autora pode ter viés. Não prova melhoria, causalidade ou efetividade em uso real. | Potencialmente viável com computador próprio e sem orçamento adicional, se critérios e avaliador estiverem disponíveis. Recomendação contextual inicial, ainda proposta. |
| A2 | Analisar cenários de busca com documentos fictícios, explicitando situações e caminhos de decisão. Depende de conseguir fundamentar situações plausíveis e representá-las em árvore de decisão. | Proposta de episódio formativo artificial com Scenarios / Scenario Analysis (análise de cenários), candidato DSREMSF sob essa condição. Pode compor S1 inicialmente; método, ambiente e trajetória precisam de aceitação. | Barreiras potenciais nos caminhos examinados; estudantes e tarefas reais não estão presentes. Cobertura depende da qualidade dos cenários e pode omitir dificuldades reais. Não confundir percorrer o fluxo com um Think Aloud de usuários. | Condicional à disponibilidade do protótipo e de base para os cenários; preparação pode consumir parte relevante do prazo. |
| A3 | Recuperar acesso a estudantes e considerar uso remoto acompanhado, com Think Aloud e tarefas reais, sem coletar documentos pessoais. Nenhum acesso remoto foi informado. | Mantém o método como candidato e exige aceitar o novo ambiente/logística. A classificação naturalística só se sustenta com usuários, sistema, tarefa e contexto reais; tarefa fictícia exige classificar e justificar a abstração. S1 também precisa ter a viabilidade da trajetória reexaminada. | Se as condições reais forem restabelecidas, pode observar dificuldades de uso. Um recorte menor reduz cobertura e deixa riscos residuais; não estabelece causalidade nem benefício de longo prazo. | Não é opção atualmente disponível. Só detalhar se o acesso for confirmado a tempo; não presumir participantes alternativos. |
| A4 | Adiar E1 e usar os três dias para preparar o planejamento, sem substituir método ou ambiente. | Preserva o desenho histórico e deixa sua realização dependente de novo acesso. Não constitui avaliação realizada nem resolve a trajetória dentro do prazo. | Pode resultar em critérios e planejamento mais claros, mas não produz evidência de usabilidade neste período. | É possível atualizar o plano agora; recuperar acesso ou ampliar prazo depende de fatos/decisões ainda ausentes. |

**Recomendação proposta:** comparar primeiro A1 com A4. A1 pode fornecer subsídios
limitados para decidir melhorias sem depender dos estudantes, se houver condições
para uma inspeção fundamentada. A4 preserva o desenho aceito, mas não entrega
evidência de usabilidade nos três dias. A2 é alternativa se critérios de inspeção
não forem a melhor base e houver cenários justificáveis. A3 depende de acesso novo.
O encurtamento do prazo não reduz automaticamente a necessidade de evidência útil.

### Redução de escopo e distribuição do prazo — propostas condicionais

Short-scoping significa reduzir o trabalho de um método ao necessário para a
decisão, explicitando a perda de cobertura. Trocar Think Aloud por inspeção é
substituição de método, não apenas redução de escopo.

- Escopo original: E1 com cinco estudantes, tarefas reais e acesso à sala, em uma
  janela de duas semanas; conjunto de tarefas e protocolo ainda não detalhados.
- Corte proposto para A1/A2: limitar a análise ao fluxo de busca ligado a P1,
  adiando P2 e caminhos secundários a identificar. Escopo final e suficiência
  para decidir melhorias ainda dependem de escolha; não fixar amostra ou limiar.
- Justificativa: priorizar O1/P1 nos três dias. Economia esperada: menos preparação,
  coordenação e análise; não há estimativa quantitativa disponível.
- Consequências: menor cobertura de tarefas e contextos; inspeção/cenários não
  recuperam observação de estudantes. Riscos residuais: problemas de aprendizagem,
  diversidade de uso e contexto podem permanecer desconhecidos.
- Se A3 se tornar viável, qualquer redução de participantes ou tarefas precisa
  de proposta própria com justificativa, cobertura e riscos. Não basta executar
  o desenho original mais depressa.
- Distribuição possível **somente após aceitação e confirmação de recursos**:
  dia 1, fundamentar critérios/cenários e delimitar escopo; dia 2, realizar a
  avaliação escolhida; dia 3, consolidar evidências e recomendações de melhoria.
  Não inclui comprovar a melhoria nem garantir implementação. Se a fundamentação
  e os recursos não estiverem disponíveis, permanecer com planejamento parcial.
- Decisão do pesquisador: pendente para A1–A4, trajetória e qualquer corte.
  Protocolos de coleta/análise exigem literatura específica do método escolhido;
  a suíte fornece condições de escolha, não esses protocolos.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

| Contexto | Item/ID | Registro e situação | Aceitação/localizador | Aplicabilidade e impacto |
|---|---|---|---|---|
| Rodada fictícia 1 | O1, P1 | Objetivo e usabilidade Must aceitos | Trecho de Ana acima | Preservados; observar P1 depende do desenho viável. |
| Rodada fictícia 1 | S1, E1 | Human Risk & Effectiveness e Think Aloud em tarefas reais aceitos | Trecho de Ana acima e seções 2 e 4 do plano anterior | Histórico preservado; S1 a revisar e E1 inviável como desenhado. |
| Rodada fictícia 1 | P2 | Confiabilidade Could continua proposta | “P2 pode continuar proposta.” | Sem mudança de prioridade ou seleção. |
| Mensagem atual, registrada em 2026-10-10 | Contexto, S1, E1, observação de P1 | “perdi acesso aos estudantes e à sala; agora só tenho três dias.” Informação fornecida, não escolha de substituto. | Mensagem do pesquisador | Revoga a disponibilidade anterior; inviabiliza E1 nas condições aceitas e exige rever acesso, trajetória e observação. O1/P1 permanecem. |
| Mesma mensagem | O1, P1 | Direção mantida | “Quero manter o objetivo de melhorar usabilidade.” | Preserva a finalidade formativa; não afirma melhoria já obtida. |
| Esta atualização | S1, E1, A1–A4, redução de escopo | Alternativas e recomendação da IA, propostas | “ainda não aceitei substituir estratégia, método ou ambiente.” | Nenhuma substituição aceita. Também não há aceitação do cronograma ou do corte de escopo. |

## Pendências e próximo passo

| Pendência | Item afetado | Informação ou decisão necessária |
|---|---|---|
| Escolher como lidar com a inviabilidade | S1, E1, A1–A4 | Aceitar uma alternativa concreta e as mudanças correspondentes, ou manter E1 adiado. |
| Confirmar recursos da alternativa | A1–A3, P1 | Disponibilidade do protótipo; quem pode avaliar e com que capacidade; base para critérios/cenários; acesso real caso A3 seja considerada. |
| Detalhar observação e literatura do método | P1, alternativa escolhida | Critérios verificáveis, escopo, protocolo e suficiência da evidência para decidir melhorias; limiar continua pendente. |
| Confirmar divisão do tempo | O1, episódio escolhido | Quanto dos três dias será dedicado à avaliação e quanto a eventuais melhorias; cronograma acima é só proposta. |

- Episódios posteriores não precisam de protocolo agora.
- Próxima pergunta útil: prefere considerar A1 (inspeção artificial baseada em
  critérios) ou A4 (adiar E1 preservando o desenho aceito)? Para A1, quem estaria
  disponível para avaliar e há critérios de usabilidade fundamentados acessíveis?

## Fontes e materiais do caso

- Plano anterior e aceitação de Ana na rodada fictícia 1; mensagem atual do
  pesquisador. São os dados do caso, sem execução empírica documentada.
- Baskerville, Pries-Heje e Venable (2026), *MEDS: Methodology for Evaluation in
  Design Science*, DOI [10.1080/0960085X.2026.2627280](https://doi.org/10.1080/0960085X.2026.2627280).
  Síntese local: “Objetivos e propriedades”, “DSREMSF: métodos candidatos por
  quadrante”, “Condições para orientar a escolha” e “Short-scoping e sinergias”.
- Venable, Pries-Heje e Baskerville (2016), *FEDS: a Framework for Evaluation in
  Design Science Research*, DOI [10.1057/ejis.2014.36](https://doi.org/10.1057/ejis.2014.36).
  Síntese local: “Finalidade, ambiente e momento”, “Estratégias arquetípicas” e
  “Aplicação na suíte”.
- Foram lidos apenas materiais desta pasta. As justificativas usam as sínteses
  locais; não foi feita consulta aos artigos integrais. Os IDs, o registro de
  situação e a classificação principal seguem convenções da suíte; a comparação
  A1–A4 e a distribuição dos três dias são julgamentos contextuais da IA.

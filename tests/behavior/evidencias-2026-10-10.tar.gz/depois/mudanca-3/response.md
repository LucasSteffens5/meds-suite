Atualizei [plano-meds.md](/private/tmp/meds-v011-o77i0s6a/after-full/mudanca-3/plano-meds.md), usando somente a skill e os recursos desta pasta.

O1 e P1 permanecem aceitos: identificar problemas de usabilidade para orientar melhorias. **E1 ficou inviável como desenhado**, pois dependia dos estudantes e das tarefas reais. Human Risk & Effectiveness permanece no histórico, com sua aplicabilidade marcada para reexame.

Registrei quatro alternativas, todas propostas:

- **A1:** avaliação artificial baseada em critérios de usabilidade; depende de critérios fundamentados e avaliador disponível.
- **A2:** análise artificial de cenários de busca; depende de situações e caminhos justificáveis.
- **A3:** Think Aloud remoto com tarefas reais, somente se houver recuperação de acesso.
- **A4:** adiar E1 e preparar o planejamento, sem produzir evidência de usabilidade nos três dias.

Recomendo considerar A1 primeiro, condicionada aos recursos necessários. Ela pode apontar problemas potenciais, mas não demonstrar melhoria no uso pelos estudantes.

A etapa atual é reexaminar a viabilidade e escolher uma alternativa. **Nenhuma substituição de estratégia, método ou ambiente foi registrada como aceita.** Critérios, protocolo, corte de escopo e divisão dos três dias seguem pendentes.
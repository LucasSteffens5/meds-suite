# Plano MEDS — Organizador de documentos (caso fictício)

Este plano descreve avaliações futuras em um exercício fictício isolado. Esta
atualização registra mudanças e alternativas; nenhuma avaliação foi executada e
nenhuma substituição de estratégia, método ou ambiente foi aceita.

## Contexto

- Identificador: organizador-documentos.
- Última atualização: 2026-10-10, retomada por mudança de recursos e acesso.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos atuais: três dias; computador próprio e ausência de orçamento adicional
  preservados do plano anterior. Distribuição do tempo entre avaliação e melhorias
  ainda pendente.
- Acesso atual: acesso aos estudantes e à sala perdido; nenhum acesso alternativo
  confirmado. Contexto anterior: duas semanas e cinco estudantes e sala da
  universidade confirmados para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Mudança declarada na retomada: "perdi acesso aos estudantes e à sala; agora só
  tenho três dias. Quero manter o objetivo de melhorar usabilidade".
- Limite decisório declarado: "ainda não aceitei substituir estratégia, método
  ou ambiente".
- Etapa atual: reexaminar estratégia e trajetória (passo 2 de MEDS) e viabilidade
  de E1 (passo 4), preservando objetivo e propriedade prioritária. Próximo passo:
  escolher uma alternativa antes de detalhar o episódio que depender dela.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito na
  rodada fictícia 1 e mantido na retomada. A finalidade continua formativa:
  produzir informação para aperfeiçoar o protótipo. Melhorar a usabilidade é a
  intenção; demonstrar que ela melhorou exigiria evidência adicional.
- A restrição de três dias aumenta a necessidade de eficiência, sem autorizar
  ampliar conclusões ou abandonar riscos de uso. A evidência deve ser suficiente
  para decidir quais dificuldades corrigir; não há exigência informada de
  certificação, comparação causal ou benefício sustentado em longo prazo.

## 2. Estratégia e trajetória

- S1 — Human Risk & Effectiveness: aceita historicamente em função dos riscos de
  uso e do acesso então informado; **a revisar quanto à viabilidade da trajetória**.
  O foco humano continua pertinente ao artefato sociotécnico e a O1/P1. A premissa
  de acesso relativamente viável ao contexto real deixou de valer. Nenhuma outra
  estratégia foi aceita; S1 não foi automaticamente revogada nem substituída.
- Trajetória aceita: E1 formativo naturalístico; episódios posteriores ainda não
  definidos. E1 está inviável nas condições atuais. Uma etapa artificial anterior
  pode ser proposta dentro de S1, que admite avaliações formativas artificiais,
  mas exige decisão sobre sua inclusão e evidência futura de uso real quando
  necessária. Essa adaptação não comprova efetividade.
- Prazo curto não basta para escolher Quick & Simple: simplicidade da construção
  e baixos riscos e incertezas sociais e técnicos não foram estabelecidos. Perda
  de acesso pode motivar examinar Technical Risk & Efficacy, mas não demonstra
  risco predominantemente técnico nem necessidade de atribuição causal. Ser
  software e estar sem usuários não torna o artefato puramente técnico.
- Fundamento: FEDS, tópicos "Estratégias arquetípicas" e "Processo original de
  quatro passos", orienta reexaminar escolhas por riscos, recursos e acesso.
  Manter S1 em revisão e comparar as alternativas abaixo é julgamento contextual,
  não uma substituição prescrita pela fonte.

## 3. Propriedades

- P1: usabilidade, Must (precisa ser avaliada), relacionada a O1; aceita e mantida.
  Observar dificuldades na busca; limiar ainda pendente. A prioridade segue a
  finalidade do artefato; o acesso perdido afeta como obter evidência, não remove
  sua relevância. Uma inspeção produziria indícios de dificuldades possíveis;
  não equivale à observação de dificuldades vividas pelos estudantes.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.
  Continua proposta, sem inclusão em E1 ou nova prioridade por causa do prazo.

## 4. Episódios

### E1 — Uso acompanhado

- O1 e P1; protótipo atual; classificação aceita: formativo naturalístico.
  Formativo significa orientar melhorias; naturalístico exige usuários, sistema,
  problema/tarefa e contexto reais. A sala, isoladamente, não define o ambiente.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Situação: **aceitação histórica preservada; execução inviável nas condições
  atuais**. Faltam usuários e acesso ao contexto previsto. Três dias também
  restringem preparação, coleta, análise e eventuais melhorias. Não se atribui
  a Ana ou à IA o papel de estudante real para simular esse acesso.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Decisão apoiada: selecionar dificuldades de busca a corrigir no protótipo.
- Responsável pela execução: não informado; Ana é a destinatária da evidência.
- Momento relativo ao desenvolvimento: protótipo atual, sem marco informado que
  permita fixar ex ante, intermediário ou ex post.
- Critérios detalhados de observação e protocolo do método: pendentes.

### Alternativas para decisão — todas propostas, não aceitas

| ID | Alternativa e impacto nas escolhas | Evidência e limites | Condições e recursos |
|---|---|---|---|
| A1 | Preservar S1 e o desenho de E1; adiar sua execução e usar os três dias para preparar a avaliação. Não substitui método ou ambiente. | Entrega planejamento e preparação, sem nova evidência de uso ou comprovação de melhoria. | Não exige participantes agora. Retomada de E1 depende de novo acesso, sem prazo confirmado. |
| A2 | Propor E1a, formativo artificial, antes de E1 dentro de S1: Criteria-Based Evaluation (avaliação por critérios), apoiada por cenários de busca fictícios. E1 permanece adiado; inclusão do episódio, método e ambiente precisam de aceitação. | Indícios de problemas de interface e navegação, com critérios e justificativas rastreáveis, para priorizar correções. Não mede dificuldades reais, aprendizagem, adoção ou efetividade entre estudantes. | Depende de protótipo acessível, critérios verificáveis, tarefas fictícias e pessoa disponível com competência para o julgamento; esses requisitos ainda não estão confirmados. Não exige a sala nem documentos pessoais. |
| A3 | Investigar outro acesso a estudantes em contexto real, possivelmente remoto, para redesenhar E1 mantendo Think Aloud e a finalidade formativa. Naturalístico só se as condições reais de uso forem confirmadas; redesenho permanece proposto. | Poderia produzir dificuldades relatadas e observadas de usuários reais. Se tarefas ou contexto forem simulados, classificar o episódio como artificial e explicitar esse alcance, mediante nova decisão. | Nenhum participante, local alternativo, recurso remoto ou viabilidade em três dias está confirmado. Sem novo acesso, não resolve a inviabilidade atual. |

Recomendação contextual, ainda **não aceita**: A2, se for necessário obter indícios
para melhorias dentro dos três dias e seus requisitos forem viáveis. A matriz
DSREMSF (Design Science Research Evaluation Method Selection Framework, quadro
para selecionar métodos de avaliação em DSR) relaciona avaliação por critérios
ao quadrante formativo artificial quando há critérios verificáveis. Cenários
podem ajudar a delimitar situações de busca; não substituem usuários reais. A1
é a alternativa que preserva integralmente o desenho aceito, com o custo de não
obter nova evidência de avaliação neste prazo. A3 depende de acesso ainda ausente.

#### Corte de escopo proposto para A2, condicionado à escolha

- Escopo original: E1 com cinco estudantes em tarefas reais e contexto
  universitário, voltado a dificuldades de usabilidade, em duas semanas.
- Alteração proposta: episódio adicional E1a, concentrado no fluxo de localizar
  documentos acadêmicos com material fictício, usando critérios selecionados.
  Não é apenas encurtar Think Aloud: muda a fonte da evidência e introduz outro
  método e ambiente; E1 não é sobrescrito.
- Justificativa e economia esperada: evitar recrutamento e logística de sala e
  reduzir tarefas e análise, mantendo foco em O1/P1. Economia qualitativa; não
  há estimativa de horas nem garantia de conclusão em três dias.
- Consequências para rigor/cobertura: cobertura limitada ao fluxo escolhido e
  dependência dos critérios e do julgamento; podem ser perdidas dificuldades de
  aprendizagem, diferenças entre estudantes e obstáculos do contexto real.
- Riscos residuais: falsos indícios, problemas não detectados e correções que não
  beneficiem estudantes. Uma avaliação futura com usuários continua pendente.
- Possível distribuição, somente se A2 for aceita e os requisitos confirmados:
  dia 1, delimitar fluxo, literatura do método e critérios; dia 2, avaliação e
  registro dos indícios; dia 3, síntese e priorização de melhorias. Implementar
  ou verificar correções depende do tempo restante e não é garantido neste plano.
- Critérios, tarefas, quantidade de cenários, limiares, responsável e protocolo
  não definidos. Exigem detalhamento e literatura própria do método; a suíte
  oferece condições de escolha, não um protocolo de execução.
- Escolha da pesquisadora: pendente. Nenhuma coleta ou inspeção realizada.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

| Contexto | Item/ID | Registro e situação | Evidência de aceitação ou informação | Aplicabilidade e impacto |
|---|---|---|---|---|
| Rodada fictícia 1 | O1; P1 | Aceitos: problemas de usabilidade para melhorias; P1 Must. | Trecho de Ana acima. | Mantidos; perda de acesso afeta operacionalização, não finalidade ou prioridade. |
| Rodada fictícia 1 | S1 | Human Risk & Effectiveness aceita. | Trecho de Ana acima. | Histórico preservado; trajetória precisa ser reexaminada após perda da premissa de acesso. |
| Rodada fictícia 1 | E1 | Formativo naturalístico, Think Aloud em tarefas reais aceitos. | Trecho de Ana acima e ficha original de E1. | Execução inviável nas condições atuais; método e ambiente não substituídos. |
| Rodada fictícia 1 | P2 | Confiabilidade Could, proposta. | "P2 pode continuar proposta." | Continua candidata para futuro; não foi aceita para execução. |
| Retomada, 2026-10-10 | Contexto; S1; E1 | De duas semanas, cinco estudantes e sala confirmados para três dias, sem acesso aos estudantes e à sala. Informação fornecida. | "perdi acesso aos estudantes e à sala; agora só tenho três dias". | Revisar viabilidade de S1/E1 e detalhamento de P1; preservar O1/P1 e restrições. |
| Retomada, 2026-10-10 | O1; P1 | Manutenção da intenção de melhorar usabilidade. | "Quero manter o objetivo de melhorar usabilidade". | Não autoriza afirmar melhoria demonstrada nem trocar propriedade. |
| Retomada, 2026-10-10 | S1; E1; A1–A3; E1a | Alternativas e recomendação da IA, propostas; nenhuma substituição aceita. | "ainda não aceitei substituir estratégia, método ou ambiente". | Decisão metodológica permanece pendente; E1a só será incorporado à trajetória mediante escolha correspondente. |

## Pendências e próximo passo

| Pendência | Item afetado | Informação ou decisão necessária |
|---|---|---|
| Escolher caminho diante do novo contexto | S1; E1; A1–A3 | Preservar e adiar E1 (A1), aceitar uma etapa artificial anterior (A2), ou investigar novo acesso real (A3). Nenhuma opção selecionada. |
| Confirmar viabilidade da alternativa | E1/E1a | Disponibilidade do protótipo, de quem avaliará e distribuição dos três dias; para A3, acesso efetivo a estudantes e contexto real. |
| Detalhar observação e critérios de P1 | P1; episódio escolhido | Critérios, tarefas, limites da evidência e limiar, se necessário à decisão. Não inventar valores. |
| Consultar literatura própria do método | E1 ou E1a | Think Aloud se E1 for retomado; avaliação por critérios se A2 for aceita. Preparar protocolo apenas para o episódio pertinente. |
| Planejar episódios posteriores | Trajetória de S1 | Adiado; não precisam de protocolo agora. Nenhum episódio futuro confirmado. |

Próximo passo: obter a escolha da pesquisadora entre as alternativas propostas,
com seus limites explícitos. Se a escolha ainda não ocorrer, este plano permanece
parcial, com E1 inviável no contexto atual e sem substituição metodológica.

## Fontes e materiais do caso

- Plano anterior deste caso e pedido de retomada: fontes do histórico, das
  restrições e das mudanças; exercício fictício, sem resultados de avaliação.
- Baskerville, Pries-Heje e Venable (2026), *MEDS: Methodology for Evaluation in
  Design Science*, DOI [10.1080/0960085X.2026.2627280](https://doi.org/10.1080/0960085X.2026.2627280).
  Síntese local consultada: "Processo e seus quatro passos", "Objetivos e
  propriedades", "DSREMSF: métodos candidatos por quadrante" e "Short-scoping e
  sinergias". Fundamenta replanejamento, prioridade e comparação de métodos.
- Venable, Pries-Heje e Baskerville (2016), *FEDS: a Framework for Evaluation in
  Design Science Research*, DOI [10.1057/ejis.2014.36](https://doi.org/10.1057/ejis.2014.36).
  Síntese local consultada: "Finalidade, ambiente e momento", "Estratégias
  arquetípicas" e "Processo original de quatro passos". Fundamenta distinção de
  estratégia, finalidade e ambiente e reexame por recursos e acesso.
- IDs, classificação principal por quadrante e registro do corte de escopo são
  convenções operacionais da suíte. A recomendação A2 é julgamento contextual da
  IA. Foram lidos apenas a skill e os recursos locais pertinentes; não houve
  consulta externa às fontes, a outras instalações ou literatura de execução.

**Não recomendo substituir E1 por testes artificiais com a finalidade de provar benefício sustentado em uso real.** Esses testes podem verificar funcionamento e saídas corretas nas condições testadas, mas não demonstram que estudantes obtêm e mantêm benefícios no cotidiano. Além disso, **o E1 atual também não pretende demonstrar benefício de longo prazo**: sua função é identificar dificuldades de usabilidade para orientar melhorias.

Reutilizo como decisões aceitas aquelas documentadas no plano: O1, P1 como Must, Human Risk & Effectiveness e E1 com Think Aloud em tarefas reais. A troca permanece uma proposta.

1. **Objetivos — seção 1 e evidência esperada de E1.**  
   O1 busca “identificar problemas de usabilidade para decidir melhorias”; E1 exclui expressamente causalidade e benefício de longo prazo. Sua proposta introduz outro objetivo: estabelecer **efetividade**, isto é, benefício mantido em condições reais de uso. Conforme MEDS, mudar a evidência pretendida exige revisitar objetivos, estratégia, propriedades e episódios. **Recomendação:** tratar esse objetivo como uma possível ampliação do programa, explicitando quem usará essa evidência e para qual decisão.

2. **Estratégia — seção 2.**  
   Human Risk & Effectiveness foi aceita pelos riscos de uso e pelo acesso confirmado a cinco estudantes para tarefas reais. Substituir a observação de uso por testes de funcionamento retiraria a avaliação direta desses riscos humanos. Segundo FEDS, a estratégia favorece avaliações naturalísticas — com usuários, sistema, tarefas e contexto reais — quando a efetividade importa. **Recomendação:** preservar essa cobertura; testes técnicos podem complementá-la. Ser software não torna o artefato puramente técnico.

3. **Propriedades — seção 3.**  
   P1 é usabilidade e está diretamente ligada a O1. Testes de funcionamento não oferecem, por si só, a evidência sobre dificuldades de aprendizagem e busca esperada em E1. Podem contribuir para aspectos de P2, confiabilidade, dependendo dos critérios e da cobertura, mas P2 continua candidata, classificada como Could. **Recomendação:** não trocar implicitamente a propriedade avaliada nem elevar P2 a decisão aceita. Para benefício sustentado, seria necessário definir uma propriedade observável correspondente ao efeito pretendido.

4. **Método e classificação — E1.**  
   Think Aloud, a verbalização dos pensamentos durante a tarefa, foi escolhido para obter retorno detalhado sobre usabilidade. Na matriz de métodos DSREMSF apresentada em MEDS, *Testing* aparece como candidato somativo artificial para verificar software, mas essa posição não garante adequação ao objetivo. A finalidade depende do uso da evidência: testes que orientam correções podem ser formativos; testes que julgam atendimento a requisitos podem ser somativos. **Recomendação:** justificar finalidade, ambiente e critérios concretos, sem atribuir efetividade ou causalidade ao simples nome do método.

5. **Recursos e corte de escopo — Contexto e substituição proposta.**  
   A troca poderia reduzir esforço de acompanhamento, mas essa economia ainda não foi estimada. Sua consequência seria perder cobertura direta de usabilidade em uso real, mantendo a incerteza sobre benefício sustentado. MEDS admite redução de escopo, desde que o rigor continue suficiente para a conclusão pretendida. **Recomendação:** explicitar economia, cobertura perdida, riscos e decisão da pesquisadora; menor custo não sustenta uma conclusão mais ampla.

Minha recomendação contextual é **manter E1 para melhorias de usabilidade**, considerar testes técnicos como complemento se houver necessidade e planejar avaliação naturalística posterior caso o benefício sustentado se torne objetivo aceito. Não há exigência de quantidade fixa de episódios.

Para avançar nessa ampliação, faltam definir: o que conta como benefício, por quanto tempo deve se manter, como será observado, o acesso a uso recorrente e os recursos disponíveis. As duas semanas e o acesso informado não demonstram, sozinhos, viabilidade desse acompanhamento. Devem permanecer as restrições de não medir notas nem coletar documentos pessoais.

O fundamento está nos recursos locais [MEDS](/private/tmp/meds-v011-o77i0s6a/before-full/beneficio-real-1/skill/references/meds.md) e [FEDS](/private/tmp/meds-v011-o77i0s6a/before-full/beneficio-real-1/skill/references/feds.md). Nenhum arquivo foi alterado.
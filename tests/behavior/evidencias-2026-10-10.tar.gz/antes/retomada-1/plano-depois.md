# Plano MEDS — Organizador de documentos (caso fictício)

Este plano descreve avaliações futuras em um exercício fictício isolado; não
registra execução nem resultados.

## Contexto

- Identificador: organizador-documentos.
- Última atualização: 2026-10-10.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos: janela de duas semanas, computador próprio, sem orçamento adicional;
  disponibilidade informada na retomada: três sessões de 40 minutos, total de
  120 minutos. Ainda não está definido se esse tempo abrange preparação, coleta
  e análise, nem como será distribuído entre essas atividades.
- Acesso: cinco estudantes e sala da universidade confirmados para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: detalhamento de E1.
- Próximo passo: esclarecer a cobertura dos 120 minutos, a tarefa real viável
  no protótipo e as dificuldades de uso que serão observadas em E1.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.

## 2. Estratégia e trajetória

- Human Risk & Effectiveness: aceita em função dos riscos de uso e do acesso informado.
- E1 formativo naturalístico; episódios posteriores ainda não definidos.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.

## 4. Episódios

### E1 — Uso acompanhado

- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.
- Recursos conhecidos: três sessões de 40 minutos; cinco estudantes e sala
  confirmados. Distribuição do tempo e viabilidade de acompanhar os cinco dentro
  desse recurso: pendentes; o acesso confirmado não equivale a uma programação
  de participação já definida.
- Detalhamento necessário: identificar a tarefa real de busca, confirmar que o
  protótipo permite realizá-la sem coletar documentos pessoais e explicitar quais
  dificuldades observar, sem atribuir critérios ou limiares à pesquisadora.
- Limiar de usabilidade: permanece pendente. E1 busca dificuldades para orientar
  melhorias; não há base para declarar a usabilidade aprovada ou reprovada.
- Ajuste de escopo: nenhum corte de participantes, tarefas ou etapas foi decidido.
  Após esclarecer o uso dos 120 minutos, verificar a viabilidade de E1. Se for
  necessário um corte, apresentar a proposta, sua economia esperada, consequências
  para cobertura/rigor e riscos residuais antes de registrar a escolha.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

Na retomada de 2026-10-10, a pessoa usuária manteve as escolhas aceitas, informou
três sessões de 40 minutos e reiterou que ainda não há limiar de usabilidade.
O recurso foi atualizado sem alterar O1, P1, a estratégia ou o método de E1;
P2 continua proposta para episódio futuro.

## Pendências e próximo passo

- Esclarecer se os 120 minutos incluem preparação, coleta e análise.
- Definir a tarefa real de busca que o protótipo já permite executar respeitando
  a restrição sobre documentos pessoais.
- Detalhar a observação de P1 em E1 a partir das dificuldades que a pesquisadora
  deseja identificar; critérios e limiar continuam pendentes, sem valores presumidos.
- Consultar literatura própria de Think Aloud para elaborar o protocolo;
  os recursos locais da suíte orientam a escolha, mas não fornecem esse protocolo.
- Episódios posteriores não precisam de protocolo agora.
- Próxima ação: obter apenas as informações acima sobre tempo, tarefa e observação
  de E1; depois verificar a viabilidade e propor a distribuição das três sessões.

## Fontes e materiais do caso

- Plano salvo e informações fornecidas nesta retomada.
- [MEDS — referência local](skill/references/meds.md): objetivos e recursos,
  condições de Think Aloud no DSREMSF (quadro de seleção de métodos de avaliação
  em DSR) e requisitos para ajustes de escopo.
- [FEDS — referência local](skill/references/feds.md): finalidade formativa,
  condições naturalísticas e recursos para desenhar episódios. A classificação
  aceita de E1 depende de preservar usuários, sistema e tarefa reais.

Atualizei [plano-meds.md](/private/tmp/meds-v011-o77i0s6a/before-full/retomada-1/plano-meds.md) com **três sessões de 40 minutos (120 minutos)** e o próximo passo de E1. Preservei as escolhas aceitas; critérios e limiar de usabilidade continuam pendentes.

Para detalhar somente E1:

1. Os 120 minutos incluem preparação, uso com estudantes e análise?
2. Qual tarefa real de busca o protótipo já permite realizar sem coletar documentos pessoais?
3. Quais dificuldades nessa tarefa você precisa identificar para decidir melhorias?
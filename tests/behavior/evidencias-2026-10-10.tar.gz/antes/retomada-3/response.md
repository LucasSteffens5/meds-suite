Atualizei [plano-meds.md](/private/tmp/meds-v011-o77i0s6a/before-full/retomada-3/plano-meds.md) com **três sessões de 40 minutos — 120 minutos totais** e o próximo passo. Usei somente a skill local e seus recursos.

As escolhas aceitas foram preservadas; o limiar de usabilidade continua pendente, sem critérios inventados. A etapa atual é o detalhamento de E1, antes de distribuir preparação, uso acompanhado e análise.

Para avançar em E1:

1. Qual tarefa real de busca os estudantes realizarão sem coletar documentos pessoais?
2. Quais dificuldades nessa busca você precisa observar para decidir melhorias?
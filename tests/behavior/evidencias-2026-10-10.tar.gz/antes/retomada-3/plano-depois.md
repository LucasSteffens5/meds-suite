# Plano MEDS — Organizador de documentos (caso fictício)

## Contexto

- Identificador: organizador-documentos.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos: duas semanas, computador próprio, sem orçamento adicional.
- Dedicação disponível informada nesta retomada: três sessões de 40 minutos
  (120 minutos no total). Distribuição entre preparação, acompanhamento de uso
  e análise ainda não definida; planejar essas atividades dentro desse recurso.
- Acesso: cinco estudantes e sala da universidade confirmados para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: detalhamento de E1.
- Próximo passo: definir a tarefa real e as dificuldades de uso que precisam ser
  observadas em E1; então distribuir preparação, uso acompanhado e análise pelas
  três sessões disponíveis.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.

## 2. Estratégia e trajetória

- Human Risk & Effectiveness: aceita em função dos riscos de uso e do acesso informado.
- E1 formativo naturalístico; episódios posteriores ainda não definidos.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.

## 4. Episódios

### E1 — Uso acompanhado

- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.
- Recursos disponíveis: três sessões de 40 minutos; cinco estudantes e sala
  confirmados para tarefas reais. O acesso confirmado não define a distribuição
  dos participantes pelas sessões nem demonstra que preparação, coleta e análise
  caberão nos 120 minutos.
- Planejamento do tempo: detalhar após definir a tarefa de E1, respeitando os
  120 minutos disponíveis. Não foi adotado corte de participantes, tarefas ou
  etapas do método.
- Observação de P1: definir com a pesquisadora a tarefa real e quais dificuldades
  na busca precisam ser registradas para orientar melhorias, respeitando a
  restrição de não coletar conteúdo de documentos pessoais.
- Limiar de usabilidade: continua pendente. Não foi criado critério de aprovação
  ou reprovação; a finalidade aceita de E1 é identificar problemas para melhorias.
- Fundamento: MEDS orienta adequar o esforço à informação necessária para a próxima
  decisão formativa. No DSREMSF, Think Aloud é candidato para retorno detalhado
  sobre usabilidade de um protótipo utilizável. A classificação naturalística
  aceita depende das condições reais de uso já previstas, conforme FEDS.
- Antes de elaborar o protocolo de execução, consultar literatura própria de
  Think Aloud; as referências locais da suíte orientam a escolha do método,
  mas não fornecem seu protocolo.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

Na retomada atual, a pesquisadora informou três sessões de 40 minutos, reafirmou
as escolhas aceitas e declarou que ainda não dispõe de limiar de usabilidade.
O recurso foi registrado; não houve nova decisão metodológica nem execução de E1.

## Pendências

- Distribuir preparação, uso acompanhado e análise de E1 pelas três sessões de
  40 minutos após definir a tarefa e o que observar.
- Definir a tarefa real de busca e as dificuldades a observar em P1, sem coletar
  conteúdo de documentos pessoais; critérios detalhados continuam pendentes.
- Buscar literatura própria do método antes de elaborar o protocolo de E1.
- Limiar de usabilidade permanece pendente, sem valor ou regra presumidos.
- Episódios posteriores não precisam de protocolo agora.

## Fontes e materiais consultados nesta retomada

- Plano existente e informações fornecidas nesta conversa fictícia.
- `skill/references/meds.md`: objetivos e propriedades; DSREMSF e condições de
  Think Aloud; eficiência e limites de ajustes de escopo.
- `skill/references/feds.md`: finalidade formativa, ambiente naturalístico e
  adequação dos recursos ao desenho do episódio.

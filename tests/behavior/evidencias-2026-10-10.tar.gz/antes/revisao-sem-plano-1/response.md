Li `skill/SKILL.md`, o fluxo Revisar e a referência MEDS desta pasta.

Envie o conteúdo do plano no chat ou indique o caminho do arquivo nesta pasta. Sem o material, ainda não é possível avaliar sua coerência.

A revisão relacionará objetivos, estratégia, propriedades e episódios, indicando a localização de cada lacuna, seu fundamento e a recomendação correspondente. A entrega será somente no chat, sem criar ou alterar arquivos.
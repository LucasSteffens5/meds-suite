# Plano MEDS — Organizador de documentos (caso fictício)

Este plano registra avaliações planejadas, não executadas. A atualização distingue
mudanças de contexto informadas, decisões já aceitas e alternativas ainda propostas.

## Contexto

- Identificador: organizador-documentos.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Última atualização: 2026-10-10, retomada do exercício fictício isolado.
- Recursos atuais: três dias; computador próprio e ausência de orçamento adicional
  permanecem conforme o plano anterior. A divisão do tempo entre avaliação e
  alterações do protótipo ainda precisa ser definida.
- Acesso atual: perda de acesso aos estudantes e à sala, informada nesta retomada.
  Não há outros usuários, avaliadores ou ambientes confirmados.
- Contexto anterior, preservado como histórico: duas semanas, cinco estudantes
  e sala da universidade confirmados para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: revisão de viabilidade da trajetória e de E1; detalhamento do
  protocolo depende da escolha entre as alternativas abaixo.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito e
  reafirmado nesta retomada. A finalidade do artefato continua sendo ajudar
  estudantes a encontrar documentos acadêmicos; a avaliação orienta melhorias.
- Necessidade de evidência: informação suficiente para priorizar a próxima
  melhoria do protótipo. Identificar problemas ou sugerir mudanças não demonstra
  que a usabilidade melhorou; essa conclusão exigiria avaliação apropriada após
  as alterações. O prazo reduzido não transforma O1 em um objetivo somativo
  (julgar atendimento final a requisitos ou padrões).

## 2. Estratégia e trajetória

- Human Risk & Effectiveness, estratégia do FEDS (quadro de avaliação em Design
  Science Research): aceita em função dos riscos de uso e do acesso então informado.
  A aceitação permanece registrada; a viabilidade de sua trajetória precisa ser
  revista, pois o acesso que a sustentava foi perdido.
- E1 formativo naturalístico: desenho aceito, atualmente inviável nas condições
  previstas. Formativo significa orientar melhorias; naturalístico exige usuários,
  sistema e tarefa reais em contexto real. A falta da sala, isoladamente, não
  determina o quadrante; a perda dos usuários e do contexto previsto impede
  sustentar aqui o desenho naturalístico original.
- Alternativa de trajetória, **proposta, não aceita**: manter Human Risk &
  Effectiveness como orientação e inserir um episódio formativo artificial nos
  três dias; retomar E1 naturalístico quando houver acesso, sem prazo confirmado.
  Artificial significa abstrair uma ou mais condições reais de uso. Segundo
  FEDS, essa estratégia admite avaliação artificial formativa inicial; contudo,
  o episódio artificial não supre a evidência de uso real pendente.
- Se a ausência de acesso for duradoura, reconsiderar a estratégia ou uma combinação
  com Technical Risk & Efficacy pode ser uma alternativa: FEDS contempla o custo
  proibitivo de avaliação real, inclusive tempo, nessa escolha. Isso exigiria
  justificar o desenho e seus limites para O1; não há mudança de estratégia aceita.
  Três dias, por si só, não justificam Quick & Simple: riscos e incertezas de uso
  continuam relevantes. O caráter sociotécnico não mudou para puramente técnico.
- Episódios posteriores continuam sem detalhamento; a alternativa artificial
  e a retomada de E1 são possibilidades, não uma trajetória nova já aprovada.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.
- MuSCoW é a priorização de propriedades: Must precisa ser avaliada; Could poderia
  ser avaliada. O prazo não altera automaticamente essas prioridades. Não se
  propõe incluir P2 no trabalho dos três dias.

## 4. Episódios

### E1 — Uso acompanhado

- Situação: desenho aceito preservado; execução inviável com o acesso atual.
- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.
- Momento relativo ao desenvolvimento, versão precisa do protótipo e responsável
  pela condução: não informados. A destinatária da evidência é Ana; não se presume
  que ela também conduzirá o método.
- Impacto: não é possível observar dificuldades dos cinco estudantes nas tarefas
  reais previstas. Reduzir o número de participantes ou o tempo de sessão não
  resolve ausência de acesso. Nenhuma autoinspeção pode ser registrada como
  execução do Think Aloud aceito com estudantes.

### Alternativas para decisão — nenhum novo episódio aceito

DSREMSF é o quadro de seleção de métodos de avaliação usado por MEDS. Suas
condições orientam a escolha, mas não fornecem protocolos de execução.

| Alternativa | Desenho e condições necessárias | Evidência possível e limites | Situação e impacto nas decisões |
|---|---|---|---|
| A — Avaliação baseada em critérios (Criteria-Based Evaluation), candidata E2-A | Formativa artificial de O1/P1; inspecionar a busca no protótipo por critérios explícitos e verificáveis de usabilidade. Depende de protótipo acessível, critérios fundamentados e responsável capaz de aplicá-los, ainda não confirmados. | Lista rastreável de problemas potenciais e recomendações. Sem estudantes, não observa sua experiência, aprendizagem ou dificuldades reais; inspeção pelo próprio autor acrescenta risco de viés. | Proposta preferencial condicionada à viabilidade desses recursos. Novo método e ambiente dependem de aceitação; pode integrar Human Risk & Effectiveness, mantendo E1 pendente. |
| B — Análise de cenários (Scenarios), candidata E2-B | Formativa artificial de O1/P1; examinar percursos de busca e decisões em situações previstas. Depende de cenários justificáveis, árvore de decisões, acesso ao protótipo e responsável, ainda não confirmados. | Identifica obstáculos potenciais nos percursos escolhidos. Cenários são construídos, não tarefas reais observadas; podem omitir necessidades e comportamentos dos estudantes. | Proposta alternativa a A, não aceita. Troca método/ambiente em relação a E1; não equivale ao Think Aloud com usuários. |
| C — Preservar E1 e adiar sua execução | Manter método e ambiente aceitos; usar os três dias para preparar critérios e protocolo, se houver recursos, e executar após recuperar acesso. Depende de disponibilidade futura, hoje desconhecida. | Produz preparação, sem nova evidência de usabilidade no prazo atual. Posteriormente, E1 poderá observar dificuldades reais conforme seu protocolo. | Proposta que preserva o desenho original; adiamento depende de escolha e não deve ser apresentado como avaliação realizada. |

A recomendação de A considera a condição DSREMSF de critérios verificáveis e a
possibilidade de examinar P1 com o computador já registrado. Não confirma
disponibilidade de competência avaliadora, literatura ou critérios. B é adequada
somente se o uso puder ser representado por cenários justificáveis. C deve ser
considerada se nenhuma alternativa fornecer evidência suficiente para decidir
melhorias. Não se propõe executar todas as alternativas no prazo.

### Recorte proposto de E2-A — condicionado à escolha de A

- Objetivo/propriedade: O1/P1; finalidade formativa; protótipo atual, versão a
  identificar. Ambiente artificial por substituir observação de estudantes
  e tarefas reais por inspeção com critérios e situações construídas.
- Escopo original de referência: E1 com cinco estudantes em tarefas reais de
  busca, duas semanas e sala. A é uma alternativa de método e ambiente,
  **não apenas uma redução do Think Aloud**.
- Short-scoping (redução justificada de escopo) dentro de A: examinar somente o
  percurso central de busca de documentos relacionado a O1/P1, deixando outros
  fluxos e P2 fora deste episódio. A existência e a delimitação desse percurso
  precisam ser confirmadas no protótipo; não há número de tarefas fixado.
- Justificativa e economia esperada: concentrar preparação, inspeção e análise
  no uso prioritário; dispensar recrutamento e logística da sala. Economia
  qualitativa, sem estimativa de horas ou garantia de conclusão em três dias.
- Evidência planejada: registro de critério e fonte, tela/etapa examinada,
  problema potencial, suporte observado no protótipo, recomendação e incerteza.
  Esse registro é uma proposta de rastreabilidade, não um protocolo validado.
- Consequências e riscos residuais: menor cobertura dos fluxos, viés do avaliador,
  falsos positivos e dificuldades reais não detectadas. Não permite alegar
  satisfação dos estudantes, melhoria comprovada, causalidade ou efetividade
  em uso real. A evidência pode orientar a priorização de mudanças, não comprovar
  seu efeito; E1 continua necessário para a evidência originalmente pretendida.
- Responsável, critérios, forma de análise e regra para priorizar problemas:
  pendentes. Nenhum limiar ou resultado foi definido como fato.
- Escolha do pesquisador: pendente; método, ambiente e recorte não aceitos.
- Literatura própria do método: necessária antes do protocolo de execução;
  não fornecida pelos recursos locais desta suíte.

Distribuição **proposta e condicional** dos três dias, caso A seja escolhida e
viável: dia 1, delimitar percurso e fundamentar critérios/protocolo; dia 2,
inspecionar e registrar problemas potenciais; dia 3, analisar e priorizar
recomendações. Não reserva automaticamente tempo para implementar e reavaliar
melhorias. A distribuição deve ser revista se os três dias incluírem essas tarefas
ou se a fundamentação e os recursos necessários não estiverem disponíveis.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

| Contexto | Item | Registro e situação | Impacto |
|---|---|---|---|
| Retomada atual | Acesso e prazo | Informado pelo usuário: perdeu acesso aos estudantes e à sala; dispõe de três dias. | Revisar viabilidade da trajetória e de E1. |
| Retomada atual | O1 | Usuário quer manter o objetivo de melhorar usabilidade; O1 preservado. | P1 continua Must; finalidade formativa mantida. |
| Retomada atual | Estratégia, método e ambiente | Usuário declara que ainda não aceitou substituições. Escolhas anteriores preservadas como aceitas; A, B, C e revisão de estratégia são propostas. | Nenhum novo episódio ou substituição autorizados por esta atualização. |

## Pendências e próximo passo

| Pendência | Item afetado | Informação ou decisão necessária |
|---|---|---|
| Escolher como tratar a inviabilidade de E1 | Trajetória/E1 | Optar por A, B, C ou outra alternativa fundamentada; registrar explicitamente alterações aceitas. |
| Confirmar recursos remanescentes | E2-A/E2-B | Protótipo utilizável no computador disponível, responsável e competência/apoio para avaliação. Não presumir novos participantes. |
| Delimitar os três dias | Escopo e cronograma | Esclarecer se incluem implementação e reavaliação ou somente avaliação. |
| Fundamentar método e observação de P1 | Episódio escolhido | Literatura própria do método, critérios, análise e regra de priorização; limiar permanece pendente. Para E1, detalhar Think Aloud quando viável. |
| Esclarecer perspectiva de recuperar acesso | Estratégia/E1 | A perda é temporária ou impede avaliação real durante todo o projeto? Não há data de retorno confirmada. |

- Próximo passo: decidir a alternativa após confirmar protótipo, responsável e
  alcance do prazo. Até essa decisão, o plano fica parcial na revisão de
  viabilidade, sem execução e sem substituições aceitas.
- Episódios posteriores não precisam de protocolo agora.

## Fontes e materiais do caso

- Plano anterior e informações desta retomada: contexto e aceitação fictícios.
- [Skill local](skill/SKILL.md) e [fluxo Planejar](skill/workflows/planejar/WORKFLOW.md):
  continuidade, preservação de decisões, alternativas e consolidação.
- [MEDS local](skill/references/meds.md), seções “Objetivos e propriedades”,
  “DSREMSF: métodos candidatos por quadrante” e “Short-scoping e sinergias”:
  relação O1/P1, condições dos candidatos e limites do recorte.
- [FEDS local](skill/references/feds.md), seções “Finalidade, ambiente e momento”
  e “Estratégias arquetípicas”: classificação dos episódios, trajetória e revisão
  da estratégia diante da mudança de acesso.
- [Modelo local do plano](skill/assets/plano-meds.md): organização do registro.
  Uso restrito a estes materiais; não houve consulta a outras instalações ou
  verificação externa dos artigos citados nas referências locais.

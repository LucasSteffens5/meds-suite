Atualizei [plano-meds.md](/private/tmp/meds-v011-o77i0s6a/before-full/mudanca-1/plano-meds.md), usando somente a skill e os recursos desta pasta.

E1 ficou inviável nas condições previstas, pois dependia dos estudantes em tarefas reais. Preservei O1, usabilidade como Must e todas as decisões aceitas; nenhuma substituição foi registrada como aceita.

Registrei três alternativas:

- **A — Avaliação por critérios:** proposta preferencial, condicionada a critérios fundamentados e avaliador disponível.
- **B — Análise de cenários:** examinar obstáculos potenciais em percursos construídos.
- **C — Adiar E1:** preparar o protocolo agora e aguardar recuperação do acesso.

A e B podem orientar melhorias, mas não comprovam melhoria da usabilidade nem substituem a evidência de uso real. Também registrei um recorte e cronograma de três dias, ambos condicionais.

A etapa atual é **revisão de viabilidade**. Permanecem pendentes a escolha da alternativa, os recursos necessários e se os três dias incluem implementar e reavaliar melhorias.
Considero **P3 — acessibilidade, Must ligada a O1 — uma decisão aceita**, conforme sua mensagem.

- **Localização e lacuna:** a seção 3 não registra P3, e E1, na seção 4, contempla apenas O1/P1. A inclusão aceita deixou uma propriedade obrigatória sem cobertura no programa.
- **Consequência:** o planejamento está incompleto quanto às propriedades Must. Segundo a referência MEDS da skill, Must significa “propriedades que precisam ser avaliadas”. A avaliação de usabilidade em E1 não assegura, por si só, cobertura de acessibilidade.
- **Próximo passo:** revisitar a seleção de propriedades e o desenho dos episódios. É necessário esclarecer o escopo de P3 e a evidência necessária para orientar melhorias em O1; então avaliar se E1 pode contemplá-la com adequação ou se a trajetória precisa de outro arranjo, considerando os recursos disponíveis.

Essa recomendação não define critérios, método adicional ou quantidade de episódios: essas escolhas permanecem pendentes. **Nenhum arquivo foi alterado.**
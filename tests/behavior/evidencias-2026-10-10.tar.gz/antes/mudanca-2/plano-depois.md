# Plano MEDS — Organizador de documentos (caso fictício)

Este plano descreve avaliações futuras. Nenhuma execução ou resultado foi
documentado. As alternativas desta retomada são propostas da IA, sem aceitação
da pesquisadora. Somente esta pasta e o pacote local foram consultados.

## Contexto

- Identificador: organizador-documentos.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Última atualização: 2026-10-10.
- Recursos atuais: três dias, conforme a retomada. Computador próprio e ausência
  de orçamento adicional constam do plano anterior, sem alteração informada.
- Acesso atual: perdeu acesso aos estudantes e à sala. Nenhum participante,
  avaliador adicional ou ambiente substituto foi confirmado.
- Condições anteriores, superadas: duas semanas e acesso a cinco estudantes e
  sala da universidade para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: revisão da viabilidade de E1 e da estratégia/trajetória, antes de
  retomar o detalhamento. Próximo passo: escolher uma alternativa e confirmar
  suas condições; nenhuma substituição metodológica está aceita.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.
  Mantido expressamente nesta retomada pelo objetivo de melhorar usabilidade.
- Melhorar a usabilidade permanece a intenção; identificar problemas e recomendar
  mudanças não demonstra que a usabilidade efetivamente melhorou.

## 2. Estratégia e trajetória

- Human Risk & Effectiveness: aceita em função dos riscos de uso e do acesso
  originalmente informado. A aceitação permanece registrada; a trajetória exige
  revisão diante da perda de acesso. FEDS é o quadro que orienta a escolha de
  estratégias e trajetórias de avaliação.
- E1 formativo naturalístico: desenho aceito, agora inviável nas condições
  informadas. Episódios posteriores ainda não definidos.
- Proposta preferida, condicionada à escolha: manter a orientação Human Risk &
  Effectiveness, incluir um episódio formativo artificial de inspeção por critérios
  e adiar E1. FEDS permite avaliações artificiais iniciais nessa estratégia;
  mudar um episódio não exige automaticamente trocar a estratégia. Esta alteração
  da trajetória ainda não foi aceita.
- A perda de acesso aumenta o custo relativo de avaliar em contexto real e pode
  motivar examinar Technical Risk & Efficacy se persistir. Não há, porém, novo
  risco técnico principal nem objetivo de atribuição causal informado que resolva
  essa escolha. Não se adotou outra estratégia.
- Três dias não bastam para justificar Quick & Simple: riscos e incertezas de uso
  permanecem. O software continua sociotécnico; ausência de estudantes não o torna
  um artefato puramente técnico.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.

MuSCoW prioriza propriedades: Must precisa ser avaliada; Could poderia ser
avaliada. As prioridades aceitas/propostas acima não foram alteradas.

## 4. Episódios

### E1 — Uso acompanhado (aceito; inviável nas condições atuais)

- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.
- Escopo original: cinco estudantes em tarefas reais; quantidade de tarefas não
  definida. Sem acesso aos estudantes e à sala, não executar esse desenho agora.
- A finalidade é formativa porque a evidência orientaria melhorias. O ambiente
  naturalístico depende de usuários, sistema e tarefa reais em contexto real;
  nem o nome Think Aloud nem a existência de outro local garantem essa condição.
- O método aceito não foi substituído por inspeção da pesquisadora. Versão do
  protótipo, responsável pela condução e momento exato em relação ao desenvolvimento
  permanecem sem informação. Ana é a destinatária da evidência.

### Impacto das novas restrições

| Item | Impacto | Tratamento |
|---|---|---|
| O1 / P1 | Usabilidade continua relevante; perde-se observação direta de dificuldades dos estudantes | Preservar O1 e P1 como Must; limitar conclusões de alternativas sem usuários |
| Estratégia / trajetória | O acesso que sustentava E1 deixou de existir e o prazo caiu de duas semanas para três dias | Revisitar trajetória sem transformar proposta em decisão aceita |
| E1 / Think Aloud | Não há condições para o episódio naturalístico aceito | Registrar inviabilidade atual, mantendo o desenho e seu histórico |
| Evidência | Inspeções e cenários só apontariam problemas potenciais; aprendizagem, experiência e uso contextual ficam sem observação | Não afirmar efetividade em uso real nem melhoria demonstrada |
| Escopo e prazo | Planejamento, coleta, análise e possíveis mudanças competem pelos três dias | Propor recorte explícito e verificar se o prazo inclui implementação |
| P2 | Não resolve a restrição de acesso nem o objetivo prioritário | Manter candidata para futuro, sem ampliar o escopo |

### Alternativas — propostas, sem novo episódio aceito

DSREMSF é a matriz de métodos candidatos por finalidade e ambiente. Suas
condições orientam a escolha, mas não fornecem protocolos de execução.

| Alternativa | Desenho e condições necessárias | Evidência possível e limites | Escolha pendente |
|---|---|---|---|
| A — Inspeção por critérios (preferida se viável) | Novo episódio formativo artificial com Criteria-Based Evaluation: requer critérios verificáveis por julgamento ou medida, protótipo acessível e pessoa capaz de aplicá-los. Ana é possível avaliadora, somente se confirmar disponibilidade e condições; não se presume especialista externo | Problemas potenciais de usabilidade e recomendações vinculadas a critérios. Sem observação de estudantes; risco de viés da própria pesquisadora e de cobertura limitada | Aceitar novo método/ambiente e alteração da trajetória; confirmar avaliadora, critérios fundamentados e escopo |
| B — Análise de cenários | Novo episódio formativo artificial com Scenarios / Scenario Analysis: requer situações de busca previsíveis em uma árvore de decisão, responsável disponível e materiais fictícios ou públicos pertinentes | Obstáculos potenciais nos percursos previstos. Depende da qualidade dos cenários; não revela comportamento espontâneo ou dificuldades reais dos estudantes | Aceitar novo método/ambiente e alteração da trajetória; confirmar cenários, responsável e materiais |
| C — Preservar E1 e adiar execução | Manter método e ambiente aceitos; usar os três dias para refinar o planejamento. Execução futura depende de recuperar acesso confirmado, sem data presumida | Produz planejamento, sem nova evidência de usabilidade no prazo. Decisões empíricas sobre melhorias ficam adiadas | Escolher o adiamento e reconhecer o limite da entrega nos três dias |

A e B são formativas porque orientariam aperfeiçoamentos e artificiais porque
afastam usuários reais e/ou tarefas reais, mesmo usando o protótipo existente.
Podem antecipar problemas para O1, mas não suprem observação posterior com
estudantes. Acesso remoto ou a outros estudantes não foi informado e não é
tratado como recurso disponível. As restrições sobre notas e documentos pessoais
continuam em todas as alternativas.

### Redução de escopo (short-scoping) proposta para A ou B

- Original: E1 com cinco estudantes, tarefas reais e observação de dificuldades;
  protocolo ainda pendente.
- Corte proposto: concentrar a avaliação na busca de documentos e nos percursos
  essenciais dessa função, deixando outras funções e P2 para depois. Quantidade
  de critérios/cenários permanece pendente até examinar os materiais.
- Separar as mudanças: retirar usuários reais e passar para A ou B altera método,
  ambiente e trajetória; não é apenas reduzir a amostra de E1.
- Justificativa: manter O1 e P1 com três dias e sem acesso aos estudantes.
- Economia esperada: menor esforço de recrutamento, deslocamento e sessões;
  estimativa qualitativa, sem duração ou custo medidos.
- Consequências para rigor/cobertura: menos funções e contextos examinados; sem
  observação de aprendizagem e dificuldades reais. Menor esforço não preserva
  automaticamente a força da evidência de E1.
- Riscos residuais: viés da avaliadora, critérios inadequados, cenários incompletos
  e prioridades que não representem as necessidades dos estudantes.
- Situação: corte proposto, não aceito nem executado.

### Organização provisória dos três dias, condicional a A ou B

| Dia | Trabalho proposto | Condição / saída esperada |
|---|---|---|
| 1 | Escolher alternativa, confirmar recursos, delimitar busca/percursos e selecionar literatura própria do método e critérios ou cenários | Desenho fundamentado, materiais permitidos e escolha registrada; condições ausentes permanecem impedimentos |
| 2 | Realizar o episódio escolhido após definir seu protocolo | Evidências rastreáveis aos critérios/cenários; responsável confirmado |
| 3 | Analisar achados e propor prioridades de melhoria para Ana | Problemas potenciais, recomendações fundamentadas e limites explícitos; implementação só se houver tempo confirmado |

Este cronograma é uma proposta de organização, não um protocolo nem garantia de
conclusão. Não implica implementação ou demonstração de melhorias. A literatura
específica do método será necessária após a escolha; o pacote local fornece o
fundamento de planejamento, sem suprir essa literatura.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

| Contexto | Item | Registro e situação | Impacto |
|---|---|---|---|
| Retomada, 2026-10-10 | Acesso e prazo | Pesquisadora informou perda de acesso aos estudantes e à sala e prazo de três dias | Supera condições anteriores; E1 inviável agora |
| Retomada, 2026-10-10 | O1 | Pesquisadora quer manter o objetivo de melhorar usabilidade | O1 preservado; P1 continua Must |
| Retomada, 2026-10-10 | Estratégia, método e ambiente | Pesquisadora declarou que ainda não aceitou substituições | Nenhuma substituição registrada como aceita |
| Atualização da IA, 2026-10-10 | A/B/C, recorte e cronograma | Propostas da IA; escolha da pesquisadora pendente | Só após escolha consolidar nova trajetória ou adiamento, preservando o histórico de E1 |

## Pendências e próximo passo

| Pendência | Item afetado | Informação ou decisão necessária |
|---|---|---|
| Escolher A, B ou C | Trajetória / E1 | Aceitação explícita da alternativa; A/B alteram método e ambiente do trabalho imediato, C adia execução |
| Delimitar prazo | Cronograma | Três dias apenas para avaliar ou também para alterar o protótipo? |
| Confirmar recursos | A/B | Protótipo utilizável e disponibilidade/condições de Ana ou outra pessoa efetivamente disponível; nenhum avaliador adicional confirmado |
| Fundamentar observação de P1 | Método escolhido | Literatura específica, critérios/cenários e protocolo; limiar continua pendente |
| Definir suficiência formativa | O1/P1 | Informação necessária para Ana decidir a próxima melhoria, dentro dos limites do desenho escolhido |
| Recuperar acesso, se futuramente possível | E1 | Usuários, sistema e tarefa reais em contexto real; sem data ou acesso presumidos |

- Episódios posteriores não precisam de protocolo agora.
- Próximo passo: escolha da pesquisadora entre A, B e C. Até essa escolha, E1
  permanece como desenho aceito e inviável agora, sem executar sua substituição.

## Fontes e materiais do caso

- Plano anterior e instrução desta retomada: decisões aceitas, recursos,
  restrições, perda de acesso, prazo e limite de autorização.
- [Skill local](skill/SKILL.md) e [fluxo Planejar](skill/workflows/planejar/WORKFLOW.md):
  continuidade e preservação de escolhas aceitas.
- [Referência local MEDS](skill/references/meds.md), seções “Processo e seus quatro
  passos”, “DSREMSF: métodos candidatos por quadrante” e “Short-scoping e sinergias”:
  revisitar etapas, comparar métodos condicionais e explicitar cortes de escopo.
- [Referência local FEDS](skill/references/feds.md), seções “Finalidade, ambiente
  e momento” e “Estratégias arquetípicas”: condições do ambiente e possibilidade
  de episódios artificiais em Human Risk & Effectiveness.
- As referências sustentam o planejamento; não demonstram eficácia, melhoria de
  usabilidade ou validade científica deste exercício.

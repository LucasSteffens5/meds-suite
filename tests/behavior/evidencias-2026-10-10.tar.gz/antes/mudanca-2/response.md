Atualizei [plano-meds.md](/private/tmp/meds-v011-o77i0s6a/before-full/mudanca-2/plano-meds.md), usando somente a skill local.

E1 com Think Aloud está **inviável nas condições atuais**. Preservei O1, usabilidade como Must e as decisões anteriormente aceitas; nenhuma substituição foi aceita.

Registrei três alternativas:

- **A — Inspeção por critérios:** preferida se houver critérios fundamentados e avaliadora disponível; apontaria problemas potenciais.
- **B — Análise de cenários:** examinaria obstáculos em percursos previstos, sem observar estudantes.
- **C — Adiar E1:** preservaria o desenho aceito, sem produzir nova evidência neste prazo.

Incluí impactos, limites, redução de escopo e cronograma condicional de três dias. A etapa atual é rever a viabilidade e a trajetória. Permanecem pendentes sua escolha, os recursos necessários e se o prazo inclui implementar melhorias.
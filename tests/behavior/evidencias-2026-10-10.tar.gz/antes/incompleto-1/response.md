Estamos na **etapa de contexto**, antes de escolher a estratégia e os métodos de avaliação. Pelo MEDS, precisamos esclarecer o efeito esperado do organizador e a decisão que a evidência deverá apoiar.

Já temos: organizador de documentos para estudantes, protótipo disponível, prazo de duas semanas, interesse em avaliar utilidade e acesso a usuários ainda não confirmado. O planejamento ficará somente no chat.

Para completar esta etapa:

1. **Problema e público:** quais estudantes são o público e qual dificuldade concreta enfrentam ao organizar documentos? Como resolvem isso hoje?
2. **Protótipo:** quais funções já podem ser usadas? Descreva uma tarefa que ele permite realizar do início ao fim.
3. **Utilidade e decisão:** que benefício você espera observar — por exemplo, encontrar documentos mais rápido ou reduzir perdas? A avaliação servirá para decidir melhorias, decidir se vale continuar o projeto ou sustentar uma conclusão para uma disciplina ou pesquisa? Quem examinará a evidência?
4. **Recursos e acesso:** das duas semanas, quanto tempo você consegue dedicar à avaliação e quanto precisa reservar para ajustes? Trabalhará sozinho? Existe alguma possibilidade concreta de convidar estudantes?
5. **Dados e riscos:** seriam usados documentos fictícios ou reais? Há dados pessoais, participantes menores de idade ou possibilidade de perder ou expor arquivos?

Com essas respostas, poderemos formular os objetivos da avaliação e explicitar as pendências de acesso.
# Plano MEDS — Organizador de documentos (caso fictício)

## Contexto

- Identificador: organizador-documentos.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos: duas semanas, computador próprio, sem orçamento adicional.
- Acesso: cinco estudantes e sala da universidade confirmados para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: detalhamento de E1.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.

## 2. Estratégia e trajetória

- Human Risk & Effectiveness: aceita em função dos riscos de uso e do acesso informado.
- E1 formativo naturalístico; episódios posteriores ainda não definidos.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.

## 4. Episódios

### E1 — Uso acompanhado

- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.

#### Proposta de short-scoping de E1 — não aceita

Short-scoping é a redução do escopo de um método, condicionada à suficiência da
evidência para a decisão pretendida, conforme a [referência MEDS local](skill/references/meds.md#short-scoping-e-sinergias).

- Escopo original informado: cinco estudantes e três tarefas reais.
- Corte proposto: dois estudantes e uma tarefa real, mantendo O1, P1 e o método
  Think Aloud já aceitos. A finalidade continuaria formativa e o ambiente
  naturalístico se preservadas as condições reais de usuários, sistema e tarefa.
- Justificativa da proposta: reduzir o esforço de E1 diante das duas semanas e
  da ausência de orçamento adicional, buscando dificuldades de usabilidade que
  possam orientar melhorias iniciais. A suficiência desse corte ainda não está
  demonstrada; eficiência, por si só, não o justifica.
- Economia esperada, qualitativa: menor esforço de agendamento e acompanhamento
  dos estudantes, preparação das tarefas, registro e análise das observações.
  Sem estimativa de horas ou custos, não se quantifica a economia; preparação do
  protocolo e cuidados com documentos pessoais continuam necessários.
- Efeitos possíveis sobre rigor: menos oportunidades de confrontar observações
  entre estudantes e tarefas; maior influência das particularidades dos dois
  participantes e da tarefa escolhida. Não se presume a mesma confiança para
  decidir melhorias que no escopo original; critérios e protocolo seguem pendentes.
- Efeitos possíveis sobre cobertura e riscos residuais: menor diversidade de
  experiências de uso e de situações de busca; dificuldades nas duas tarefas
  retiradas ou em outros estudantes podem passar despercebidas, enviesando a
  priorização de melhorias. A escolha da tarefa única precisaria ser justificada
  em relação a O1 e P1, sem presumir que representa as três tarefas.
- Efeitos possíveis sobre conclusões: a evidência poderia indicar dificuldades
  observadas nos dois estudantes durante uma tarefa e sugerir melhorias iniciais.
  Não sustentaria afirmar cobertura dos problemas, saturação, frequência entre
  estudantes ou generalização para outras tarefas; ausência de dificuldade
  observada não demonstraria ausência de problemas. Permanecem os limites de E1
  quanto a causalidade e benefício de longo prazo.
- Escolha do pesquisador: corte **não aceito**, conforme a declaração nesta rodada
  fictícia: "Não aceitei o corte." Trata-se somente de proposta, sem alteração do
  escopo vigente de cinco estudantes e três tarefas reais nem das escolhas já
  aceitas. Não há execução ou economia realizada registrada. Eventual adoção
  depende de aceitação explícita e justificativa de suficiência da evidência para
  a próxima decisão de melhoria.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

## Pendências

- Detalhar observação de P1 em E1 e buscar literatura própria do método.
- Episódios posteriores não precisam de protocolo agora.

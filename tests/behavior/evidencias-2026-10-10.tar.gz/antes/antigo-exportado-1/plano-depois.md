# Plano MEDS — Avaliação do indexador

Exercício fictício isolado. Este documento descreve avaliações futuras: não há
resultados, execução registrada ou validação científica. O plano é parcial e foi
migrado com as informações disponíveis. Interpretações e propostas da migração
não constituem novas escolhas aceitas.

MEDS (Methodology for Evaluation in Design Science) organiza o programa de
avaliações de um artefato em Design Science Research (DSR). Os identificadores
O1, P1 e E1 foram preservados para relacionar objetivo, propriedade e episódio.

## Contexto

- **Identificador do caso:** `indexador` (convenção organizacional da migração).
- **Última atualização:** 2026-10-10; data das aceitações anteriores não informada.
- **Etapa atual e próximo passo:** passo 4 de MEDS, detalhamento de E1; informar
  versão e critérios de correção, depois especificar os casos sintéticos.
- **Problema da pesquisa e finalidade da solução:** problema não informado;
  a solução realiza indexação, mas finalidade específica e requisitos estão pendentes.
- **Artefato a avaliar:** algoritmo de indexação já implementado, descrito no
  plano antigo como puramente técnico. Classificá-lo como produto é uma
  interpretação da migração; criticidade para segurança não informada.
- **Questão de pesquisa:** não informada.
- **Estágio do projeto DSR:** não informado; apenas a implementação do algoritmo
  e o caráter futuro da avaliação são conhecidos.
- **Destinatários da evidência e necessidades conhecidas:** pesquisadora Ana;
  examinar correção das saídas em casos sintéticos. Rigor exigido e outros
  destinatários não informados.
- **Recursos, acesso, riscos e restrições:** uma semana e computador próprio;
  sem participantes. Datas, disponibilidade diária, capacidade do computador,
  acesso à implementação, orçamento, riscos e recursos destinados às demais
  atividades DSR não informados. Ausência de participantes não comprova ausência de riscos.

### Aplicabilidade e limites de MEDS

O objeto é um artefato implementado cuja correção será julgada; isso permite
organizar objetivos, estratégia, propriedade e episódio com MEDS, mantendo um
plano parcial. Esta é uma interpretação metodológica da migração (M1, “Processo
e seus quatro passos” e “Aplicação e limites”), não uma aceitação adicional de
Ana. O plano não avalia a qualidade editorial de uma publicação nem comprova
eficácia do artefato ou validade científica da pesquisa.

## 1. Objetivos da avaliação

| ID | Objetivo do programa | Relação com a finalidade do artefato | Necessidade de rigor/riscos/recursos | Situação da escolha |
|---|---|---|---|---|
| O1 | Julgar correção das saídas em casos sintéticos. | Examina as saídas do algoritmo de indexação; requisitos específicos pendentes. | Critérios, cobertura e rigor exigido pendentes; uma semana e computador próprio disponíveis. | Aceito por Ana no registro antigo. |

O1 é o objetivo da avaliação; a finalidade específica da solução continua
pendente. Rigor, eficiência, redução de incertezas/riscos e ética são dimensões
de planejamento em MEDS (M1, “Objetivos e propriedades”), mas não foram
acrescentadas como objetivos aceitos.

## 2. Estratégia e trajetória

- **Estratégia aceita:** Purely Technical Artefact, de FEDS (Framework for
  Evaluation in Design Science Research), quadro que orienta estratégia e trajetória.
- **Componentes abrangidos:** algoritmo de indexação; não foram informados outros componentes.
- **Justificativa:** a descrição puramente técnica e o foco em saídas sintéticas
  sustentam uma trajetória artificial. M2, “Estratégias arquetípicas”, considera
  essa estratégia quando não há aspectos sociais ou a aplicação humana é tão
  distante que a avaliação naturalística é irrelevante ou inviável. O contexto
  de uso humano não foi detalhado; a aceitação preservada não demonstra que
  todas essas condições foram verificadas. Ser software e não ter participantes
  não bastam, por si sós, para estabelecer essas condições.
- **Trajetória preliminar:** E1 é o único episódio registrado, somativo artificial,
  futuro, sobre o algoritmo já implementado. Não foram adicionados episódios.
- **Informações necessárias para refinar a estratégia:** finalidade específica,
  contexto de uso, criticidade/riscos, distância da aplicação humana e eventual
  necessidade de evidência além dos casos sintéticos. Novos dados podem exigir
  revisão da escolha, preservando o histórico de aceitação.

## 3. Propriedades a avaliar

MuSCoW prioriza propriedades em Must (precisam ser avaliadas), Should (deveriam),
Could (poderiam) e Would (seria desejável incluir). Somente P1 foi registrada.

| ID | Propriedade e relação com a finalidade do artefato | Objetivos relacionados | MuSCoW: Must/Should/Could/Would | Justificativa | Como observar; critérios conhecidos ou pendentes | Situação da escolha |
|---|---|---|---|---|---|---|
| P1 | Correção das saídas do algoritmo de indexação; requisitos específicos pendentes. | O1 | Must | Necessária ao julgamento previsto em O1; prioridade já aceita. | Comparar saídas obtidas com saídas esperadas é proposta de operacionalização. Casos, saídas esperadas, regra de comparação, métricas e limiares permanecem pendentes. | Correção e Must aceitas por Ana; operacionalização ainda proposta. |

## 4. Episódios planejados

DSREMSF (Design Science Research Evaluation Method Selection Framework) é uma
matriz de métodos candidatos. A classificação principal abaixo permite consultá-la;
em FEDS, finalidade e ambiente são eixos contínuos e independentes. Quadrante,
estratégia e método são distintos e não garantem rigor por seus nomes.

### E1 — Julgamento da correção em casos sintéticos

- **Finalidade principal, uso da evidência e objetivos:** somativa, aceita;
  julgar a correção das saídas (O1), conforme critérios ainda pendentes. A
  finalidade decorre desse julgamento, não do momento da implementação.
- **Usos complementares da evidência:** não informados.
- **Propriedades abrangidas:** P1, correção, Must.
- **Artefato/versão ou estágio:** algoritmo já implementado; versão pendente.
- **Ambiente principal e condições:** artificial, aceito. A tarefa é sintética,
  não há participantes e o algoritmo implementado é o sistema a avaliar. Ambiente
  de execução e outras condições parcialmente reais não informados. O caráter
  sintético da tarefa fundamenta a classificação (M2, “Finalidade, ambiente e momento”).
- **Métodos candidatos e condições DSREMSF:** Testing é o método já escolhido.
  M1, “Condições para orientar a escolha”, situa-o no quadrante somativo artificial
  quando software predomina e funcionamento/saídas corretas são essenciais;
  admite testes funcionais/caixa-preta ou estruturais/caixa-branca. Modalidade
  não escolhida; implementação não inspecionada nesta migração.
- **Método aceito e justificativa:** Testing (testes), aceito por Ana, compatível
  com examinar saídas de um algoritmo implementado em casos sintéticos. A
  adequação do desenho depende dos critérios e da cobertura a definir.
- **Momento e escopo:** futuro, ex post em relação à implementação (interpretação
  da migração). Escopo informado: correção das saídas em casos sintéticos;
  quantidade, categorias e cobertura dos casos pendentes.
- **Responsáveis previstos:** não informados. Ana é destinatária e autora das
  aceitações; não foi registrada como executora.
- **Recursos e acesso:** uma semana, computador próprio, sem participantes;
  acesso ao código/executável, dependências, capacidade e cronograma detalhado pendentes.
- **Evidência esperada:** proposta de registro de entradas, saídas esperadas,
  saídas obtidas, comparação e identificação da versão/ambiente. Nenhum registro
  de execução foi fornecido.
- **Limitações:** conclusões restritas à versão e aos casos efetivamente testados,
  conforme critérios e cobertura. Testes sintéticos, por si sós, não demonstram
  correção universal, efetividade em uso real, desempenho ou segurança.
- **Sinergias:** E1 já relaciona O1 e P1; não há outros itens registrados.
- **Short-scoping (redução justificada do escopo de um método):** nenhum corte
  proposto ou aceito. Uma semana é restrição de recurso, não registro de redução.
- **Pendências e literatura específica:** versão, critérios, casos/saídas esperadas,
  modalidade, cobertura, análise, responsável e ambiente. Literatura de Testing
  para o protocolo está pendente; DSREMSF não fornece protocolo de execução.

## Decisões e mudanças

| Data ou contexto disponível | Item | Escolha | Proposta/aceita | Quem decidiu e registro da aceitação | Impacto nos demais itens |
|---|---|---|---|---|---|
| Registro antigo; data não informada | O1 | Julgar correção | Aceita | Ana; A1 abaixo. | Orienta P1 e E1. |
| Registro antigo; data não informada | P1 | Correção, Must | Aceita | Ana; A1 e descrição explícita de P1 no plano antigo. | Propriedade abrangida por E1, ligada a O1. |
| Registro antigo; data não informada | Estratégia | Purely Technical Artefact | Aceita | Ana; A1. | Orienta trajetória artificial; contexto a detalhar. |
| Registro antigo; data não informada | E1 | Somativo artificial com Testing, relacionado a O1 e P1 | Aceita | Ana; A1 e descrição explícita de E1 no plano antigo. | Requer versão e critérios antes da execução. |
| Migração em 2026-10-10 | Documento | Reorganização no modelo local; inclusão de aplicabilidade, justificativas, localizadores e lacunas | Atualização documental solicitada; não é nova aceitação metodológica de Ana | Pedido do usuário nesta sessão. | Preserva escolhas; não acrescenta resultados. |
| Migração em 2026-10-10 | P1 / E1 | Comparação entre saídas esperadas e obtidas e registro de evidência | Proposta de operacionalização | IA, a partir de O1 e das condições de Testing em M1; sem aceitação registrada. | Depende de detalhamento dos critérios e casos. |

**A1 — Registro de aceitação preservado:** Ana disse “Aceito O1, P1, a estratégia
e E1 com Testing.” O plano antigo também declarava P1 como correção, Must, e E1
como somativo artificial, relacionado a O1 e P1. Data da aceitação não informada.

## Pendências e próximo passo

| Pendência | Item afetado | Informação ou decisão necessária |
|---|---|---|
| Identificação da implementação | E1 | Versão/identificador verificável e acesso ao código ou executável. |
| Critérios de correção | O1, P1, E1 | Requisitos, definição de saída correta, origem das saídas esperadas, regra de comparação e julgamento; métricas/limiares se pertinentes. |
| Casos sintéticos e cobertura | P1, E1 | Entradas, saídas esperadas, categorias, quantidade e justificativa da cobertura. |
| Protocolo e literatura de Testing | E1 | Modalidade, procedimentos de execução/análise e literatura específica. |
| Responsabilidade e viabilidade | E1 | Executor/analista, datas e disponibilidade na semana, ambiente, dependências e capacidade do computador. |
| Contexto e riscos | Contexto, O1, estratégia | Problema, finalidade específica, questão/estágio de pesquisa, criticidade, riscos e contexto de uso humano. |
| Rigor e recursos do projeto | O1, estratégia, E1 | Necessidades de Ana e eventuais outros destinatários, suficiência da cobertura e recursos para as demais atividades DSR. |

- **Próxima pergunta útil:** qual versão do algoritmo será avaliada e quais
  requisitos determinam uma saída correta nos casos sintéticos?
- **Próxima ação:** incorporar essas informações e detalhar E1; manter lacunas
  explícitas enquanto não forem fornecidas. A migração não requer nova confirmação
  das escolhas já aceitas e não inclui execução dos testes.

## Fontes e materiais do caso

Este arquivo contém o contexto, as escolhas, o registro de aceitação, as
justificativas e as pendências necessárias para retomar o planejamento. Pode ser
movido sozinho: não contém links operacionais ou caminhos absolutos para o plugin.
Os caminhos locais na tabela identificam apenas a proveniência da migração;
não são dependências para a retomada. Títulos, DOIs e seções localizam as fontes.

Foram lidas somente as sínteses e os recursos desta pasta, sem verificação externa
dos metadados ou consulta aos artigos originais. Não se presume leitura humana
das fontes nem se atribuem páginas específicas a trechos não consultados.

| ID | Fonte ou material | Localizador | Uso no plano |
|---|---|---|---|
| C1 | Plano antigo “Avaliação do indexador (caso fictício anterior ao modelo atual)” | `plano-meds.md` antes da migração: parágrafos de contexto, O1/P1/estratégia/E1 e “Registro antigo”; aceitação preservada em A1. | Única fonte factual do caso e das escolhas aceitas. |
| T1 | Modelo e fluxo da skill local, versão 0.1.0 | `skill/assets/plano-meds.md`; `skill/workflows/planejar/WORKFLOW.md`, “Condução” e “Saída”; `skill/SKILL.md`, “Continuidade”. | Estrutura, manutenção de IDs e aceitações, lacunas e salvamento no mesmo caminho. |
| M1 | Baskerville, R., Pries-Heje, J., & Venable, J. R. (2026). *MEDS: Methodology for Evaluation in Design Science*. European Journal of Information Systems, 35(5), 830–847. | DOI: [10.1080/0960085X.2026.2627280](https://doi.org/10.1080/0960085X.2026.2627280). Síntese `skill/references/meds.md`: “Processo e seus quatro passos”, “Objetivos e propriedades”, “DSREMSF: métodos candidatos por quadrante”, “Condições para orientar a escolha”, “Short-scoping e sinergias” e “Aplicação e limites”. | Aplicabilidade, distinção objetivo/propriedade, Must, Testing e limites. |
| M2 | Venable, J., Pries-Heje, J., & Baskerville, R. (2016). *FEDS: a Framework for Evaluation in Design Science Research*. European Journal of Information Systems, 25(1), 77–89; publicação antecipada em 2014. | DOI: [10.1057/ejis.2014.36](https://doi.org/10.1057/ejis.2014.36). Síntese `skill/references/feds.md`: “Finalidade, ambiente e momento”, “Estratégias arquetípicas” e “Aplicação na suíte”. | Estratégia aceita, finalidade somativa, ambiente artificial, momento relativo à implementação e classificação principal de E1. |

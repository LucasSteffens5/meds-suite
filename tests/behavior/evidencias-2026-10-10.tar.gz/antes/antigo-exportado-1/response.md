Atualizei [plano-meds.md](/private/tmp/meds-v011-o77i0s6a/before-full/antigo-exportado-1/plano-meds.md) no mesmo caminho, seguindo o modelo local.

Preservei O1, P1, a estratégia e E1 aceitos. Registrei as lacunas, a aplicabilidade e os localizadores das fontes. O arquivo pode ser movido sozinho, sem depender do plugin.

A etapa atual é o detalhamento de E1; versão do algoritmo, critérios de correção e casos sintéticos continuam pendentes.
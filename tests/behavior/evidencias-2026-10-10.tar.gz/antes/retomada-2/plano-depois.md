# Plano MEDS — Organizador de documentos (caso fictício)

## Contexto

- Identificador: organizador-documentos.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos: duas semanas, computador próprio, sem orçamento adicional.
- Disponibilidade informada nesta retomada: três sessões de 40 minutos,
  totalizando 120 minutos de dedicação. Distribuição entre preparação, uso
  acompanhado e análise ainda pendente; não equivale a três sessões confirmadas
  com estudantes.
- Acesso: cinco estudantes e sala da universidade confirmados para tarefas reais.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: detalhamento de E1.
- Última atualização: 2026-10-10.
- Próximo passo: especificar a tarefa real de busca e as dificuldades a observar
  em E1, esclarecer quais atividades cabem nos 120 minutos e verificar a
  viabilidade do episódio com esse recurso.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.

## 2. Estratégia e trajetória

- Human Risk & Effectiveness: aceita em função dos riscos de uso e do acesso informado.
- E1 formativo naturalístico; episódios posteriores ainda não definidos.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.

## 4. Episódios

### E1 — Uso acompanhado

- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.
- Recursos: três sessões de 40 minutos de dedicação informadas; acesso aos cinco
  estudantes e à sala preservado conforme o plano. Participação em cada sessão e
  alocação de tempo ainda não definidas. Não foi decidido reduzir participantes
  ou tarefas para caber nesse tempo.
- Detalhamento imediato: identificar a tarefa real de busca que será acompanhada,
  sem coletar documentos pessoais, e as dificuldades que a pesquisadora pretende
  observar. Critérios, métricas e limiar de usabilidade não foram acrescentados.
- A adequação do método ao orçamento de tempo precisa ser verificada após esse
  detalhamento. Conforme MEDS, eficiência deve preservar informação suficiente
  para decidir melhorias; o nome do método não fornece um protocolo de execução.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

Na retomada de 2026-10-10, o usuário informou três sessões de 40 minutos e
reafirmou que as escolhas aceitas continuam. O1, P1 como Must, Human Risk &
Effectiveness e E1 com Think Aloud em tarefas reais permanecem aceitos; P2
permanece proposta. O limiar de usabilidade continua desconhecido. A nova
disponibilidade afeta o detalhamento e a viabilidade de E1, sem registrar uma
nova decisão sobre distribuição de tempo ou redução de escopo.

## Pendências

- Detalhar observação de P1 em E1 e buscar literatura própria do método.
- Especificar a tarefa real de busca e as dificuldades de interesse para E1,
  respeitando a restrição de não coletar documentos pessoais nem medir notas.
- Esclarecer se os 120 minutos incluem preparação e análise ou somente o uso
  acompanhado, e como essa disponibilidade coincide com o acesso aos estudantes.
- Limiar de usabilidade: pendente, sem valor presumido. E1 visa identificar
  dificuldades para orientar melhorias; não há base para julgar aprovação ou
  reprovação da usabilidade.
- Episódios posteriores não precisam de protocolo agora.
- Próxima ação: obter somente as informações de tarefa/observação e abrangência
  do tempo para detalhar E1. Em seguida, apoiar o protocolo em literatura própria
  de Think Aloud e verificar se preparação, coleta e análise cabem no recurso
  informado. Qualquer corte de escopo necessário deverá ser proposto com suas
  consequências e dependerá de escolha do pesquisador.

## Fontes e materiais do caso

- Plano salvo e informações desta retomada; exercício fictício, sem execução
  de avaliação ou resultados registrados.
- [MEDS — referência local](skill/references/meds.md): seções “Condições para
  orientar a escolha” e “Short-scoping e sinergias”, para adequação do método,
  proporcionalidade dos recursos e limites de cortes de escopo.
- [FEDS — referência local](skill/references/feds.md): seções “Finalidade,
  ambiente e momento” e “Estratégias arquetípicas”, para a classificação e a
  estratégia já aceitas.
- Literatura específica de Think Aloud: ainda pendente; as referências da
  suíte não fornecem o protocolo de execução.

# Plano MEDS — Organizador de documentos (caso fictício)

Este plano descreve avaliações futuras em um exercício fictício isolado. A revisão
do planejamento não demonstra melhoria de usabilidade nem execução da avaliação.

## Contexto

- Identificador: organizador-documentos.
- Última atualização: 2026-10-10, retomada com mudança de acesso e prazo.
- Artefato: protótipo de software sociotécnico, não crítico para segurança.
- Finalidade: ajudar estudantes a encontrar documentos acadêmicos.
- Destinatária da evidência: pesquisadora Ana, para decidir melhorias do protótipo.
- Recursos atuais: três dias, conforme informado nesta retomada. Computador próprio
  e ausência de orçamento adicional permanecem registrados do plano anterior;
  a disponibilidade de avaliadores e a divisão do prazo entre avaliação e melhorias
  ainda precisam ser esclarecidas.
- Acesso atual: acesso aos estudantes e à sala perdido. A confirmação anterior de
  cinco estudantes e sala da universidade deixou de valer. Não há novo acesso a
  usuários ou ambiente de uso documentado.
- Restrição declarada por Ana: "Não quero medir notas nem coletar documentos pessoais."
- Etapa atual: revisitar estratégia e trajetória (passo 2 de MEDS) e a viabilidade
  de E1 (passo 4), preservando o objetivo e a propriedade já aceitos.
- Próximo passo: decidir entre as alternativas abaixo e esclarecer os recursos
  necessários à alternativa escolhida antes de detalhar seu episódio.

## 1. Objetivos da avaliação

- O1: identificar problemas de usabilidade para decidir melhorias; aceito.
  Mantido nesta retomada pelo pedido de melhorar usabilidade. Melhorar o artefato
  é a intenção; demonstrar que ele melhorou exigiria evidência adicional.

## 2. Estratégia e trajetória

- Human Risk & Effectiveness: estratégia aceita anteriormente, voltada aos riscos
  humanos/de uso e à efetividade no contexto real. A aceitação está preservada;
  sua trajetória precisa ser revista porque o acesso que a sustentava foi perdido.
- E1 formativo naturalístico: desenho aceito anteriormente, atualmente inviável
  nas condições previstas. Episódios posteriores ainda não definidos.
- Nenhuma substituição de estratégia, método ou ambiente foi aceita nesta retomada.
  As alternativas da seção 4 são propostas, não uma nova trajetória aprovada.
- Fundamento: FEDS permite que Human Risk & Effectiveness comece com avaliação
  formativa artificial. Assim, propor um episódio artificial não obriga a trocar
  a estratégia, mas muda a trajetória e o tipo de evidência disponível. O risco de
  uso permanece mesmo sem acesso aos estudantes. O prazo curto, por si só, não
  justifica Quick & Simple; ser software não torna o artefato puramente técnico.
  Tampouco foi estabelecida necessidade de uma estratégia de eficácia técnica.

## 3. Propriedades

- P1: usabilidade, Must, relacionada a O1; aceita. Observar dificuldades na busca;
  limiar ainda pendente.
  Must significa que a propriedade precisa ser avaliada na priorização MuSCoW.
  A perda de acesso muda a possibilidade de observação direta, não sua prioridade.
- P2: confiabilidade, Could, candidata para episódio futuro; proposta.

## 4. Episódios

### E1 — Uso acompanhado

- Situação: aceito no plano anterior; execução nas condições originais impedida
  pela perda de acesso. Não cancelado nem substituído por esta atualização.
- O1 e P1; protótipo atual; formativo naturalístico.
- Think Aloud Protocol Analysis, aceito: observar dificuldades com usuários reais,
  sistema real e tarefa real, sem coletar conteúdo de documentos pessoais.
- Evidência esperada: dificuldades de uso para orientar melhorias; não pretende
  estabelecer causalidade nem benefício de longo prazo.
- Critérios detalhados de observação e protocolo do método: pendentes.

### Impacto da mudança

| Item | Impacto | Consequência para a decisão |
|---|---|---|
| O1 e P1 | A necessidade de melhorar usabilidade permanece | Manter objetivo e prioridade aceitos; ajustar o modo de obter evidência somente após decisão |
| Estratégia e trajetória | Perdeu-se a condição de acesso relativamente viável ao uso real | Rever a trajetória; a estratégia aceita não foi automaticamente substituída |
| E1 e Think Aloud | Não há acesso documentado aos participantes nem à sala previstos | Não programar sua execução como se esses recursos estivessem disponíveis |
| Ambiente de E1 | Não se sustentam atualmente as condições de usuários, sistema e tarefa reais no contexto de uso | Preservar o desenho original como inviável no presente; qualquer novo ambiente é proposta |
| Prazo | De duas semanas para três dias | Concentrar eventual avaliação em P1 e nas decisões de melhoria mais urgentes; cobertura e análise podem diminuir |
| Evidência | Observação de dificuldades dos estudantes indisponível nas condições atuais | Inspeção ou cenários podem levantar problemas potenciais, mas não demonstram usabilidade ou efetividade em uso real |

Perder a sala, isoladamente, não obrigaria a classificar uma avaliação como
artificial: uso remoto poderia ser naturalístico se usuários, sistema e tarefa
fossem reais no contexto real. Aqui também se perdeu o acesso aos estudantes;
não há base para presumir que uma alternativa remota esteja disponível.

### Alternativas para decisão — todas propostas

Os quadrantes combinam finalidade e ambiente. **Formativa** significa gerar
informação para aperfeiçoar o artefato; **artificial** significa abstrair ao menos
uma condição real de usuários, sistema ou tarefa; **naturalística** exige essas
condições no contexto real. DSREMSF é a matriz de métodos candidatos usada por MEDS.

| Alternativa | Estratégia e trajetória propostas | Episódio e método | Requisitos e evidência esperada | Limites e situação |
|---|---|---|---|---|
| A — Adiar E1 e preservar seu desenho | Manter Human Risk & Effectiveness e retomar E1 quando houver acesso | E1 formativo naturalístico com Think Aloud, conforme aceito | Recuperar acesso a usuários, protótipo utilizável e tarefas reais em contexto real; detalhar protocolo | Não entrega nova evidência de uso nos três dias com os recursos informados; adiamento ainda não aceito |
| B — Inspeção por critérios antes de eventual E1 | Manter a estratégia aceita, propondo uma etapa artificial inicial; E1 ficaria para uma oportunidade futura, sem acesso garantido | Novo episódio candidato, formativo artificial, com Criteria-Based Evaluation (avaliação por critérios) de P1 | Confirmar quem pode avaliar, sua competência, acesso ao protótipo e critérios fundamentados verificáveis por julgamento ou medida; levantar problemas potenciais para priorizar melhorias | Julgamento do avaliador não equivale à observação dos estudantes; vieses e problemas contextuais podem permanecer; inclusão do episódio e adiamento de E1 não aceitos |
| C — Análise de cenários antes de eventual E1 | Manter a estratégia aceita, propondo uma etapa artificial inicial; retomada naturalística continua dependente de acesso futuro | Novo episódio candidato, formativo artificial, com Scenarios / Scenario Analysis (análise de cenários) de P1 | Confirmar protótipo e conhecimento das situações de busca; formular situações previstas em uma árvore de decisão, explicitar suposições e examinar caminhos e obstáculos | Tarefas previstas ou fictícias abstraem o uso real; não revelam necessariamente dificuldades espontâneas ou percepções dos estudantes; inclusão do episódio e adiamento de E1 não aceitos |

Proposta preferencial para discussão: B, caso exista avaliador com competência e
critérios fundamentados disponíveis no prazo. A condição de escolha de
Criteria-Based Evaluation no DSREMSF é a existência de critérios verificáveis por
julgamento ou medida. Se essa condição não puder ser atendida, C pode ser
considerada quando houver conhecimento suficiente das tarefas e decisões de busca;
sem esses recursos, A mantém explícita a ausência de evidência nova. Nenhuma dessas
condições foi confirmada e nenhuma alternativa foi escolhida pelo pesquisador.

Para B, exemplos apenas propostos de aspectos a examinar são clareza dos rótulos
de busca, compreensão do retorno e recuperação após uma busca sem resultados.
Ainda precisam de fundamento, critérios observáveis e vínculo com a decisão de
melhoria; não são métricas ou limiares aceitos. Para C, as situações devem ser
baseadas em requisitos ou conhecimento documentado, com lacunas marcadas como
suposições, sem inventar observações dos estudantes.

### Redução de escopo proposta e prazo condicional

Redução de escopo (*short-scoping*) deve declarar o que se perde, além da economia.
Trocar Think Aloud por inspeção ou cenários é uma mudança de método e de ambiente,
não apenas uma redução do E1 aceito. Eliminar todos os participantes não preserva
a evidência de Think Aloud com estudantes.

- Escopo original: E1 com cinco estudantes, protótipo atual e tarefas reais em sala,
  ao longo dos recursos então previstos de duas semanas; protocolo ainda pendente.
- Corte candidato para B ou C: concentrar o novo episódio em P1 e em um subconjunto
  justificado dos caminhos de busca relevantes para a próxima decisão de melhoria.
  Quantidade e seleção desses caminhos permanecem pendentes. P2 continua candidata
  a episódio futuro, sem ampliação do episódio atual.
- Justificativa: prazo de três dias e ausência do acesso necessário ao E1 original.
- Economia esperada: menos coordenação de participantes, agendamento, caminhos
  examinados e material para análise; não há estimativa quantitativa disponível.
- Consequências: menor cobertura de tarefas e contextos, ausência de observação dos
  usuários na alternativa artificial e menor confiança sobre dificuldades de uso
  real. Os achados serviriam para propor melhorias, sem demonstrar sua eficácia.
- Riscos residuais: julgamento enviesado, problemas não previstos, diversidade de
  estudantes e contextos não representada, e retrabalho quando houver uso real.
- Decisão: corte, novo episódio e eventual adiamento de E1 pendentes de aceitação.

Se B ou C for escolhida e seus requisitos forem confirmados, uma distribuição
proposta dos três dias é: dia 1, delimitar caminhos e fundamentar critérios ou
cenários; dia 2, realizar o episódio escolhido; dia 3, analisar e priorizar
melhorias. Esta distribuição não é um protocolo nem um compromisso de execução.
Se o prazo também precisar incluir implementar melhorias, será necessário ajustar
essa distribuição e o escopo. Não há avaliador designado nem atividades executadas.
Protocolos de coleta e análise exigem literatura própria do método; o pacote local
fornece orientação de seleção, não esses protocolos.

## Decisões e mudanças

Ana, na rodada fictícia 1: "Aceito O1, P1 como Must, Human Risk & Effectiveness e
E1 com Think Aloud em tarefas reais. P2 pode continuar proposta."

- Retomada em 2026-10-10, informação do usuário: acesso aos estudantes e à sala
  perdido; prazo restante de três dias; objetivo de melhorar usabilidade mantido.
  Essas informações atualizam o contexto, sem aceitar mudança metodológica.
- Registro explícito do usuário: "ainda não aceitei substituir estratégia, método
  ou ambiente". Human Risk & Effectiveness, P1, O1 e o desenho original de E1
  permanecem como decisões anteriormente aceitas; a viabilidade de E1 está afetada.
- Propostas da IA nesta retomada: A, B e C, corte de escopo e distribuição condicional
  do prazo. Nenhuma registrada como aceita. Não foram produzidos resultados de uso.

## Pendências

| Pendência | Item afetado | Informação ou decisão necessária |
|---|---|---|
| Escolher como prosseguir | Estratégia/trajetória e episódios | Decidir A, B ou C, ou propor outra alternativa; documentar aceitação de qualquer mudança de método ou ambiente |
| Confirmar recursos da alternativa | B ou C | Informar quem poderá avaliar, competência, disponibilidade, acesso ao protótipo e critérios ou conhecimento das tarefas disponíveis |
| Delimitar o prazo | Escopo e cronograma | Esclarecer se os três dias incluem implementação de melhorias ou somente avaliação e análise |
| Operacionalizar P1 | Episódio escolhido | Definir observáveis, caminhos cobertos e evidência suficiente para priorizar melhorias; métricas e limiares ainda pendentes |
| Fundamentar protocolo | Método escolhido | Buscar literatura própria do método após a escolha; não presumir protocolo fornecido pela suíte |
| Possibilidade de retomar E1 | Trajetória futura | Confirmar novo acesso a usuários e contexto real, caso exista; nenhuma recuperação está garantida |

- Detalhamento da observação de P1 em E1 permanece pendente para quando houver
  condições de retomar seu desenho aceito.
- Episódios posteriores não precisam de protocolo agora.
- Próxima ação útil: escolher uma alternativa e esclarecer os recursos e o alcance
  do prazo que condicionam seu detalhamento. Até lá, o plano permanece parcial.

## Fontes e materiais do caso

- Plano anterior e mensagens do exercício: contexto, aceitação da rodada fictícia 1
  e mudança de acesso/prazo nesta retomada.
- [MEDS — referência local](skill/references/meds.md): processo e seus quatro passos;
  condições do DSREMSF; short-scoping e sinergias; limites das conclusões.
- [FEDS — referência local](skill/references/feds.md): finalidade e ambiente;
  estratégias arquetípicas; aplicação na suíte. Fundamenta manter separados
  estratégia, quadrante do episódio e método.
- [Fluxo Planejar e retomar](skill/workflows/planejar/WORKFLOW.md): revisão de escolhas
  afetadas, propostas até aceitação e registro de cortes de escopo.
- Somente os recursos locais do pacote foram usados nesta atualização. Literatura
  específica de execução dos métodos não foi consultada; continua pendente.

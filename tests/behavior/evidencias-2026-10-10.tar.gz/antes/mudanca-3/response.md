Atualizei [plano-meds.md](/private/tmp/meds-v011-o77i0s6a/before-full/mudanca-3/plano-meds.md), usando somente a skill e os recursos desta pasta.

Mantive O1, usabilidade como Must e as escolhas anteriormente aceitas. E1 ficou registrado como inviável nas condições atuais, sem substituição aprovada.

Registrei três alternativas:

- **A:** adiar E1 até recuperar acesso.
- **B:** propor avaliação formativa artificial por critérios, condicionada a avaliador e critérios fundamentados.
- **C:** propor análise formativa artificial de cenários, condicionada ao conhecimento das tarefas.

B é a recomendação condicional para discussão. B e C podem identificar problemas potenciais, mas não demonstram melhoria em uso real.

A etapa atual é rever trajetória e viabilidade dos episódios. Permanecem pendentes sua escolha, os recursos disponíveis e esclarecer se os três dias também incluem implementar melhorias.